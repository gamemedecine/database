"""
	Student List
"""

from os import system
from pwinput import pwinput
from Student import Student

students:list=[]
con:str=""
def addstudent()->None:
    global students
    system("cls")
    print("Add Student")
    print("-----------------------")
    ###
    idno:str=input("IDNO :")
    lastname:str=input("Lastname :")
    firstname:str=input("Firstname :")
    course:str=input("Course :")
    level:str=input("Level :")
    s: Student = Student (idno,lastname,firstname,course,level)
   
    students.append(s)
    return None
    
def findstudent()->bool:
    system("cls")
    print("Find Student")
    print("-----------------------")
    id =  str(input("ID: "))
    print("-----------------------")
    index:int = 0  
    for item in students:
        if item.__eq__(id):
            index = students.index(item)
            s = students[index]
            print(s)
              
    ##[prin(s) for s in slist]
  ################ delete 
def deletestudent():
    
    system("cls")
    print("Delete Student")
    print("-----------------------")
    idno=  str(input("ID: "))
    print("-----------------------")
    
    index:int = 0  
    s:Student = None
    for item in students:
        if item.__eq__(idno):
            index = students.index(item)
            s = students[index]
            print(s)
            ok:str=input("Do you want to delete this student(y/n)")
            if ok == "y":
                students.pop(index)
            
			
#def showallstudent()->None:
 #   global students
 #   system("cls")
  #  print("Student List")
   # print("-----------------------")
   # for st in students:
    #    student_values:list=st.values()
    #    [print(v,end=" ",flush=True) for v in student_values]
    #    print("")
  
def showallstudent()->None:
	global students
	system("cls")
	print("Student List")
	print("-----------------------")
	if len(students)>0:
		[print(s) for s in students]
		print("------------------------")
def quit()->None:
    print("Program Terminated")

def showmenu()->None:
    system("cls")
    menulist:tuple=(
        "------ Main Menu ------",
        "1. Add Student",
        "2. Find Student",
        "3. Delete Student",
        "4. Display All",
        "0. Quit/End",
        "-----------------------",
    )
    [print(menuitem) for menuitem in menulist]

def getmenuoption(option:int)->None:
    options={
        1:addstudent,
        2:findstudent,
        3:deletestudent,
        4:showallstudent,
        0:quit
    }
    return options.get(option)()


def login()->bool:
    okey:bool =False
    system("cls")
    username:str = input("Username:")
    password:str = pwinput(prompt="Password:",mask="*")
    if username=="admin" and password=="user": # using short circuit notation
        okey=True
    return okey
   

def main()->None:
    okey:bool=login()
    option:int = 999
    if okey:
        while option!=0:
            showmenu()
            try:
                option=int(input("Enter option(0..4):"))
                getmenuoption(option)
            except:
                print("Invalid Input")
            finally:
                    input("Press any to continue...")
    else:
        print("Invalid User...program ends")
    
if __name__=="__main__":
    main()
