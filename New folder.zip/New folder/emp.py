"""
    Create a menu
"""
def displaymenu()->None:
    system("cls")
    menu:list=[
        "----- Menu -----",
        "1. Addition",
        "2. Subtract",
        "3. Multiply",
        "4. Division",
        "0. Quit/End",
        "----------------"
    ]
    [print(menuitem) for menuitem in menu]




def main()->None:
    option:int = 999
    while option!=0:
        try:
            displaymenu()
            option=int(input("Enter Option(0..4):"))
            getmenu(option)    
        except:
            print("Invalid Input")
        finally:
            input("Press any key to continue....")

if __name__=="__main_":
    main()