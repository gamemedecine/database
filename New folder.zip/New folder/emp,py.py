"""
    Create a menu
"""
from os import system

def addition()->None:
    print("Addition Operation")
    print("------------------")

def subtract()->None:
    print("Subtract Operation")
    print("------------------")

def multiply()->None:
    print("Addition Operation")
    print("------------------")

def divide()->None:
    print("Addition Operation")
    print("------------------")

def quit()->None:
    print("Program Terminated")
   

def displaymenu()->None:
    system("cls")
    menu:list=[
        "----- Menu -----",
        "1. Addition",
        "2. Subtract",
        "3. Multiply",
        "4. Division",
        "0. Quit/End",
        "----------------"
    ]
    [print(menuitem) for menuitem in menu]


def getmenu(opt:int)->None:
    menuoption={
        1:addition,
        2:subtract,
        3:multiply,
        4:divide,
        0:quit,
    }
    return menuoption.get(opt)() #transform the value into a function,
                                 #using the () symbol    


def main()->None:
    option:int = 999
    while option!=0:
        try:
            displaymenu()
            option=int(input("Enter Option(0..4):"))
            getmenu(option)    
        except:
            print("Invalid Input")
        finally:
            input("Press any key to continue....")

if __name__=="__main_":
    main()