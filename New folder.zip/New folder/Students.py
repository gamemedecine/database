"""
	Student Class extends from Person class
"""
class Person():
    def __init__(self,lastname:str,firstname:str)->None: #class constructor
        self.lastname = lastname
        self.firstname = firstname
    
    def __str__(self)->str:
        return f"{self.lastname} {self.firstname}"
    
class Student(Person):
    def __init__(self,idno:str,lastname:str,firstname:str,course:str,level:str)->None:
        super().__init__(lastname,firstname)
        self.idno = idno
        self.course = course
        self.level = level

    def __eq__(self,idno)->bool: #object equality checker
        return self.idno == idno

    def __str__(self)->str:
        return f"{self.idno} {super().__str__()} {self.course} {self.level}"

def main()->None:
    slist:list = [
        Student("0001","durano","dennis","bscpe","4"),
        Student("0002","sample","user","bsit","3"),
        Student("0003","hello","world","bscs","2"),
        Student("0004","alpha","bravo","bscream","1"),
    ]
    
    [print(s) for s in slist]
    
    idno:str = input("Enter IDNO to delete:")
    index:int = 0
    
    s:Student = None
    
    for item in slist:
        if item.__eq__(idno):
            index = slist.index(item)
            s = slist[index]
            print(s)
            ok:str=input("Do you want to delete this student(y/n)")
            if ok == "y":
                slist.pop(index)
    
    [print(s) for s in slist]
    


if __name__=="__main__":
    main()
    