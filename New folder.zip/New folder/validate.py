from os import system
from random import randint


def vali(val:int):
    if(val > 0 and val <=20):
        return True       

def display():
        system("cls")
        print("Predict The number")

def correct():
    print(f"CORRECT! it only took{i} tries ")     
def main():
    
    ran:int=randint(1,20)
    num=0
    i=1
    while(True): 
        display()
        
        try:          
            num=int(input("Enter a number(1..20): "))  
            
            if(vali(num)):
                if(num>ran):
                    print("Lower")
                    while(ran !=num):
                        num=int(input("Enter a number(1..20): "))
                          
                        if(num > ran):
                            print("Lower")
                        if(num< ran):
                            print("Higher")                                         
                
                if(num<ran):
                    print("Higher")
                    while(ran !=num):                         
                        num=int(input("Enter a number(1..20): "))                    
                        if(num > ran):
                                print("Lower")
                        if(num< ran):
                                print("Higher")                      
            else:
                print("please enter a Postive number and does not excess to (20)")
        i=i+1                
        except:
                print("invalid please enter a number ")
        
        num=num
          
    print(f"Correct it only took{i}try")   
   

if __name__=="__main__":
    main()
 