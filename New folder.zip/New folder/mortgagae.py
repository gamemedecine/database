"""
	Mortgage Calculator
"""
from os import system
system ("cls")

def GetpartialRate(par:int):
    par = par/100
    par =par/12
    
    return par
   
def MonsthsTOpay(yr,rt):
    yr = yr*12
    prtm = 1+rt
    partialPT=1
    
    for i in range (yr+1):
        partialPT=partialPT*prtm
    
    return partialPT
       
def main():
    while(True):      
        try:
            prin=int(input("Enter Amount: "))
            Rate=int(input("Enter Rate: "))
            year=int(input("Enter Year: "))
            Rate = GetpartialRate(Rate)
            year = MonsthsTOpay(year,Rate)
            PratialPrinciple= Rate*prin
            pttl = PratialPrinciple*year
            partialR = year-1
            Total = pttl/year
            print(f"Total is : {Total}")
            
            break
        except:
            print("invalid")
            break   
    input("Press any keys")    
  




if __name__=="__main__":
    main()