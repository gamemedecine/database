"""
    A program that would accept a positive integer value not greater than
    255, display the binary equivalent of the given value
    traditional conversion
"""
from os import system

def decbin(n:int)->None:
    result:str = ""
    while n>0:
        bin:int = n%2
        result+=str(bin)
        n //= 2
    print(result[::-1])

def decbin2(n:int)->None:
    #using bitwise operators
    for i in range(7,-1,-1):
        bin=n >> i
        bin &= 0x01 #masking the unwanted bit(s)
        print(bin,end="")
   

def main()->None:
    system("cls")
    try:
        n:int = int(input("Enter value (1..255):"))
        if n>0 and n<=255:
            decbin2(n)
        else:
            print("Enter a positive value not greater than 255")
    except:
        print("Invalid Input")

if __name__=="__main__":
    main()