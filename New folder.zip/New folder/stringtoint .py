s:list=["0002","tinoy","dave","350.50"]

pp = s[3]

print(type(pp))

