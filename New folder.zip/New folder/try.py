
from os import system
def showmenu()->None:
    system("cls")
    menulist:tuple=(
        "------ Main Menu ------",
        "1.Fined Employee",
        "2.Display all Employee",
        "3.Add number of day(s) worked ",
        "4.Generate Payroll ",
        "0. Quit/End",
        "-----------------------",
    )
    [print(menuitem) for menuitem in menulist]


def main()->None:
    option:int = 999
   
    while option!=0:
        showmenu()
        try:
            option=int(input("Enter option(0..4):"))
           # getmenuoption(option)
        except:
            print("Invalid Input")
        finally:
            input("Press any to continue...")
    
    
if __name__=="__main__":
    main()