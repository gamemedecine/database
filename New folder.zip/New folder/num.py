""""
Name:Dave Ralph C. Tinoy

""""
def check(value:int):
    if(value <=10 and value > 0):
        return True
        
def main():
    n: int = 999
    while (n!=0):
        try:
            n= int(input("Enter Number: "))
            if (check(n)):
                for i in range(1,n+1):
                    for j in range (i,n+1):
                        print(j,end=" ")
                    for k in range(1,i):
                        print (k,end=" ")
                    print()
                break
            else:   
                print("Input should be a positive number and should not exceed to (10)")    
        except:
            print("invalid")
      
if __name__=="__main__":
    main()      