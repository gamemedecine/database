from flask import Flask,render_template,request,flash,session,redirect
from os import system
from sys import path
path.insert(0,"util/")
path.insert(0,"service/")

from dbhelper import *
from service.studentservice import *
from service.userservice import *

app=Flask(__name__)
app.secret_key="&^@#!@SS!"


@app.route("/main")
def main():
    tableheader:list=['idno','lastname','firstname','course','level']
    students:list = getallrecord('student')
    return render_template("main.html",rows=students,header=tableheader)
    
    
@app.route("/validateuser",methods=['POST'])
def validateuser():
    uname:str =request.form["username"]
    pword:str =request.form["password"]
    user: dict = login(username=uname,password=pword)
    if user!=None:
        flash("Login Successfull")
        return redirect("/main")
    else:
        flash("Login Failed")
        return redirect("/")
        
@app.route("/")
def index():
    return render_template("login.html")

if __name__=="__main__":
    app.run(debug=True)