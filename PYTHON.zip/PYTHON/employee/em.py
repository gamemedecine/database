from os import system
from Employee import Employee

filename:str="employee.csv"
fileposition:str="position.csv"
filepayroll:str="payroll.csv"
slist:list=[]
plist:list=[]
employ:list=[]

def header(message:str)->None:
    system("cls")
    print(message.upper())
    print("---------------------------")



    
def displaymenu()->None:
    system("cls")
    menu:tuple=(
        "---------- Main Menu ----------",
        "1. Find Employee",
        "2. Display all employee",
        "3. Add number of day(s) work",
        "4. Display payroll",
        "0. Quit/End",
        "-------------------------------"
    )
    [print(menuitem) for menuitem in menu]
#-------------------------------------------------------------------------------------   
def quit()->None:
    header("Program ends...")

def getmenuoption(opt:int)->None:
    menuoption:dict={
        1:findemployee,
        2:displayemployee,
        3:addnumofwork,
        4:displaypay,
        0:quit,
    }
    return menuoption.get(opt)()
    

def addnumofwork()->None:  
    header("Add number of day(s) work")
    loader()
    position()
    
    header("Find Employee")
    idno:str = input("IDNO :")
    found:bool = False 
    if len(slist)>0:
        for s in slist:
            if s.__eq__(idno):
                found=True
                break   
        if found==True:
            s1= str(s)
            p1= s1.split(",")
            employ=[p1[0],p1[1],p1[2],p1[3]] 
            empos=employ[3]
            print(f"{p1[0]} {p1[1]} {p1[2]} {emposition(empos)}")
            numofdays=int(input("Enter number of day(s) work   :"))
            for p in plist:
                if empos == p[0]:
                    s = int(float(p[2]))
                    Total = s *numofdays
                    print(f"{p1[0]} {p1[1]} {p1[2]} {p[1]} {Total}.00")
                    f=open(filepayroll,"a") #a-append
                    f.write(p1[0]+","+p1[1]+","+p1[2]+","+p[1]+","+str(Total)+".00"+"\n")
                    f.close()
            
        else:
            print("Employee Not Found !!!") 
    else:
        print("List is Empty!!")
   
#-------------------------------------------------------------------------------------       
def findemployee()->None:
    loader()
    position()
    header("Find Employee")
    idno:str = input("IDNO :")
    found:bool = False 
    if len(slist)>0:
        for s in slist:
            if s.__eq__(idno):
                found=True
                break   
        if found==True:
            s1= str(s)
            p1= s1.split(",")
            employ=[p1[0],p1[1],p1[2],p1[3]] 
            empos=employ[3]
            print(f"{p1[0]} {p1[1]} {p1[2]} {emposition(empos)}")                        
        else:
            print("Employee Not Found !!!") 
    else:
        print("List is Empty!!")
    print("---------------------------")
"""            
            while pos1 != pos2
                
                pos2=plist[i]
                if pos1 == pos2:                   
                    idn= employ[0]
                    lname=employ[1]
                    fname= employ[2]
                    pos = plist[1]
                    salary = plist[2]
                    employlist:list=[idn,lname,fname,pos,salary]
                    idnum = employlist[0]
                    lastname = employlist[1]
                    firstname= employlist[2]
                    post = employlist[3]
                    sal= employlist[4]
                    print(idnum+" "+lastname+""+firstname+" "+post+" "+sal)
                i
"""               
#-------------------------------------------------------------------------------------   
def loader()->None:
    slist.clear()   # clear the list
    
    f=open(filename,"r")   
    for s in f:
        data:list = s.strip("\n").split(",") #split() will return a list data separated with comma 
        student:Employee = Employee(data[0],data[1],data[2],data[3])    
        slist.append(student)
        
    f.close()
    
#-------------------------------------------------------------------------------------      
def position():
    plist.clear()   # clear the list
    f=open("position.csv","r") 
    for s in f:
        data:str= s.strip("\n").split(",") #split() will return a list data separated with comma
        ss=(data[0],data[1],data[2])
        plist.append(ss)
    f.close()
        
def emposition(pos:str):
    for p in plist:
        if pos == p[0]:
            return f"{p[1]} {p[2]}"
            
        
#-------------------------------------------------------------------------------        
def displaypay():
    header("Dispkay payroll")
    f=open(filepayroll,"r")
    for s in f:
        data:list = s.strip("\n").split(",") #split() will return a list data separated with comma 
        roll=(data[0],data[1],data[2],data[3],data[4])    
        idno=str(data[0]) 
        lastname = str(data[1]) 
        firstname =  str(data[2]) 
        position= str(data[3]) 
        salary = str(data[4]) 
      
        Paid=dict({
        'idno':idno,
        'lastname':lastname,
        'firstname':firstname,
        'position':position,
        'salary':salary,
        })
        payroll:list=[]
        payroll.append(Paid)     
        #check if slist has data
        if len(payroll)>0:
            for st in payroll:
                Pay:list=st.values()
                [print(v,end=" ",flush=True) for v in Pay]
                print("")
        else:
            print("List is Empty!")
def displayemployee()->None:
    header("display all")
    f=open(filename,"r")
    loader() 
    #check if slist has data
    if len(slist)>0:
        #[print(st) for st in slist]
        for allemployee in slist:
            s1= str(allemployee)
            p1= s1.split(",")
            employ=[p1[0],p1[1],p1[2],p1[3]] 
            empos=employ[3]
            print(f"{p1[0]} {p1[1]} {p1[2]} {emposition(empos)}") 
        
    else:
        print("List is Empty!")
        
    print("---------------------------")
    
    
def main()->None:
    opt:int = -1
    
    
    while opt!=0:
        displaymenu()
        #try:
        
            
        opt=int(input("Enter Option(0..4):"))
        getmenuoption(opt)
        #except Exception as e:
        print("Invalid Input")
        #finally:
            
        input("Press any key to continue...")
    
if __name__=="__main__":
	main()