class Person(object):
    def __init__(self,lastname:str,firstname:str)->None:
        self.lastname=lastname
        self.firstname=firstname
    
    def __str__(self)->str:
        return f"{self.lastname},{self.firstname}"
    
class Employee(Person):
    def __init__(self,idno:str,lastname:str,firstname:str,position:str)->None:
        super().__init__(lastname,firstname)
        self.idno=idno
        self.position=position
        
        
    def __str__(self)->str:
        return f"{self.idno},"+super().__str__()+f",{self.position}"

    def __eq__(self,idno:str)->bool:
        return self.idno==idno





