from os import system
from Employee2 import Employee2

filename:str="employee.csv"
fileposition:str="position.csv"
slist:list=[]
plist:list=[]
employ:list=[]
def header(message:str)->None:
    system("cls")
    print(message.upper())
    print("---------------------------")



    
def displaymenu()->None:
    system("cls")
    menu:tuple=(
        "---------- Main Menu ----------",
        "1. Find Employee",
        "2. Display all employee",
        "3. Add number of day(s) work",
        "4. Display payroll",
        "0. Quit/End",
        "-------------------------------"
    )
    [print(menuitem) for menuitem in menu]
#-------------------------------------------------------------------------------------   
def quit()->None:
    header("Program ends...")

def getmenuoption(opt:int)->None:
    menuoption:dict={
        1:findemployee,
        2:displayemployee,
        3:addnumofwork,
        0:quit,
    }
    return menuoption.get(opt)()
    

def addnumofwork()->None:
    header("Add number of day(s) work")
   
#-------------------------------------------------------------------------------------       
def findemployee()->None:
    loader()
    position()
    header("Find Employee")
    idno:str = input("IDNO :")
    found:bool = False
    if len(slist)>0:
        for s in slist:
            if s.__eq__(idno):
                found=True
                break   
        if found==True:
            print(s)
            s1= str(s)
            
            
        else:
            print("Employee Not Found !!!")
    else:
        print("List is Empty!!")

#-------------------------------------------------------------------------------------   
def loader()->None:
    slist.clear()   # clear the list
    
    f=open(filename,"r")    
    for s in f:
        data:list = s.split(",") #split() will return a list data separated with comma 
        student:Employee = Employee(data[0],data[1],data[2],pp[1],pp[2])    
        slist.append(student)
            
    f.close()
  
#-------------------------------------------------------------------------------------      

def displayemployee()->None:
    header("display all")
 
    loader()
    
    #check if slist has data
    if len(slist)>0:
        [print(st,end="",flush=True) for st in slist]
    else:
        print("List is Empty!")

def main()->None:
    opt:int = -1
    
    while opt!=0:
        displaymenu()
        #try:
        
            
        opt=int(input("Enter Option(0..4):"))
        getmenuoption(opt)
        #except Exception as e:
        print("Invalid Input")
        #finally:
            
        input("Press any key to continue...")
    
if __name__=="__main__":
	main()