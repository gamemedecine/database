l:list=["f1","foreman 1","750.50"]

position=l[2]

print(position)