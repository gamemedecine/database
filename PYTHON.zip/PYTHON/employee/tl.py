slist:list=[]
fileposition:str="position.csv"
f=open(fileposition,"r")

for s in f:
    data:str= s.strip("\n").split(",") #split() will return a list data separated with comma
    ss=(data[0],data[1],data[2])
    slist.append(ss)
print(slist[0])
  
    
"""

for s in f:
        data:list = s.split("\n") #split() will return a list data separated with comma 
        dat =str(data)
        
        d1:list= dat.split(",")
        g= d1[0]
        g1:list= g.split("[")
        gg= g1[1]
        
print(gg)        
       # print(slist[0])   
       
        #for d in tp:
          #  plist.append(d)
"""


"""  
for s in f:
    data:list = s.split(",") #split() will return a list data separated with comma
    dat1=data[0]
    dat2=data[1]
    dat3=data[2]
    slist=[dat1,dat2,dat3]
print(slist[2])
f.close()

"""    
""" 
for s in f:
    data:list = s.split(",") #split() will return a list data separated with comma
    dat1=data[0],data[1],data[2],
    slist=[dat1]
print(slist[0])
f.close()
  
for s in f:
    slist.clear()   # clear the list
    data:list = s.split(",") #split() will return a list data separated with comma
    dat= (data[0],data[1],data[2])
    
    slist.append(dat)     
      
f.close()

print(slist)
""" 