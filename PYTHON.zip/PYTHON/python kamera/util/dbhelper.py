from mysql.connector import connect 

db=connect(
    host="127.0.0.1",
    user="root",
    password="",
    database="student"
)
def getallrecord(table:str):
    sql:str =f"SELECT * FROM `{table}`"
    cursor:object=db.cursor(dictionary=True)
    cursor.execute(sql)
    rows:list =cursor.fetchall()
    return rows
def getrecord(table:str,**kwargs)->dict:
    keys: list = list(kwargs.keys())
    values: list = list(kwargs.values())
    sql:str = f"SELECT * FROM `{table}` WHERE `{keys[0]}`='{values[0]}'"
    cursor:object = db.cursor(dictionary=True)
    cursor.execute(sql)
    row:dict=cursor.fetchone()
    return row
    
def deleterecord(table:str,**kwargs)->bool:
    keys: list = list(kwargs.keys())
    values: list = list(kwargs.values())
    sql:str = f"DELETE FROM `{table}` WHERE `{keys[0]}`='{values[0]}'"
    cursor:object = db.cursor()
    cursor.execute(sql)
    db.commit()
    cursor.close()
    row :int =cursor.rowcount
    ok:bool = False
    if row>0:
        ok=True
    return ok
    
def addrecord(table:str,**kwargs)->bool:
    ok:bool = False
    values:list=list(kwargs.values())
    keys:list=list(kwargs.keys())
    fields:str="`,`".join(keys)
    data:str="','".join(values)
    sql:str= f"INSERT INTO `{table}`(`{fields}`) VALUES('{data}')"
    cursor:object = db.cursor()
    cursor.execute(sql)
    db.commit()
    cursor.close()
    row :int =cursor.rowcount
    if row>0:
        ok=True
    return ok
    
    
    
def updaterecord(table:str,**kwargs)->bool:
    ok: bool = False
    values: list = list(kwargs.values())
    keys: list = list(kwargs.keys())
    flds: list = []
    for i in range(len(values)):
        #flds.append(f"`{keys[i]}`='{str(values[i])}'")
        flds.append("`"+keys[i]+"`='"+values[i]+"'")
    fields: str = ",".join(flds)
    sql: str = f"UPDATE `{table}` SET {fields} WHERE `idno`={values[0]}"
    cursor:object = db.cursor()
    cursor.execute(sql)
    db.commit()
    cursor.close()
    row :int =cursor.rowcount
    if row>0:
        ok=True

    return ok
    

#rows :list = getallrecord('student')
#[print(r,end=" ") for r in rows]
#row:dict =getrecord('student',idno='0005')
#print(row)
#row:bool = deleterecord('student',idno='0002')
#print(row)
#row:bool=addrecord('student',idno='0204',lastname='juana',firstname='mari',course='bsit',level='3')
#print(row)
#row:bool=updaterecord('student',idno='0002',lastname='oresga',firstname='nina',course='education',level='4')
#print(row)
