--3
USE Salesco2;
GO

CREATE PROCEDURE SP_POPULATEVENDOR
    @VendorName VARCHAR(50)
AS
/*-- =============================================
-- Author Create date:  Description:	
-- DAVE    2023-4-14		populate VENDOR table
-- =============================================*/
BEGIN
    IF EXISTS(SELECT 1 FROM VENDOR WHERE VENDOR_NAME = @VendorName)
    BEGIN
        UPDATE VENDOR SET ISACTIVE = 'Y', DATE_CREATED = GETDATE() WHERE VENDOR_NAME = @VendorName;
    END
    ELSE
    BEGIN
        INSERT INTO VENDOR (VENDOR_NAME) VALUES (@VendorName);
    END;
END;
GO
EXEC SP_POPULATEVENDOR 'Bryson inc.';
EXEC SP_POPULATEVENDOR 'D&E Supply';
EXEC SP_POPULATEVENDOR 'Gomez Bro';
EXEC SP_POPULATEVENDOR 'Superloo inc.';
EXEC SP_POPULATEVENDOR 'Brackman Brox.';
USE Salesco2;
GO
/*-------------------------------------------------------------------------------*/
CREATE PROCEDURE SP_POPULATEPRODUCT
    @PROD_DESCRIPTION varchar(100),
    @PROD_ONHAND INT,
    @PROD_PRICE decimal,
    @PROD_DISCOUNT DECIMAL(4,2),
    @VENDOR_NAME VARCHAR(50)
AS
/*-- =============================================
-- Author Create date:  Description:	
-- DAVE    2023-4-14		populate PRODUCT table
-- =============================================*/
BEGIN
    DECLARE @VENDOR_CODE INT;
    
    SELECT @VENDOR_CODE = vendor_id FROM VENDOR WHERE VENDOR_NAME = @VENDOR_NAME;
    
    IF(@VENDOR_CODE IS NOT NULL)
    BEGIN
        UPDATE PRODUCT
        SET PROD_DESCRIPTION = @PROD_DESCRIPTION,
            PROD_ONHAND = @PROD_ONHAND,
            Prod_Price = @PROD_PRICE,
            PROD_DISCOUNT = @PROD_DISCOUNT,
            VEND_CODE = @VENDOR_CODE
        WHERE VEND_CODE = @VENDOR_CODE;
        
        IF @@ROWCOUNT = 0
        BEGIN
            INSERT INTO PRODUCT(PROD_DESCRIPTION, PROD_ONHAND, Prod_Price, PROD_DISCOUNT, VEND_CODE)
            VALUES (@PROD_DESCRIPTION, @PROD_ONHAND, @PROD_PRICE, @PROD_DISCOUNT, @VENDOR_CODE);
        END
    END
END
EXEC SP_POPULATEPRODUCT 'Claw Hammer', 32, 99.75, 0.02, 'Bryson Inc';
EXEC SP_POPULATEPRODUCT 'Sledge Hammer', 15, 115.24, 0.04, 'Bryson Inc';
EXEC SP_POPULATEPRODUCT 'jigsaw', 23, 258.75, 0.10, 'Bryson Inc';
EXEC SP_POPULATEPRODUCT 'Metal Screw', 172, 32.15, 0.00, 'Bryson Inc';
EXEC SP_POPULATEPRODUCT 'Nails', 237, 25.20, 0.05, 'Bryson Inc';


