USE [PUT_TINOY2]
/*
1. Update the standard cost and list price of the following products:
a. Freewheel
- Change the standard cost from 0.00 to 13.25
- Change the list price from 0.00 to 17.75
b. Flat Washer 1
- Change the standard cost from 0.00 to 55.35
- Change the list price from 0.00 to 67.55
*/

;WITH CTE__ProductsToUpdate AS (
    SELECT PRODUCT_ID, PRODUCT_NAME
    FROM PRODUCT
)

UPDATE PRODUCT
SET STANDARD_COST = 13.25,
    LIST_PRICE = 17.75
FROM PRODUCT
JOIN  CTE__ProductsToUpdate
ON PRODUCT.PRODUCT_ID =  CTE__ProductsToUpdate.PRODUCT_ID
WHERE CTE__ProductsToUpdate.PRODUCT_NAME = 'Freewheel';

;WITH CTE__ProductsToUpdate AS (
    SELECT PRODUCT_ID, PRODUCT_NAME
    FROM PRODUCT
)
UPDATE PRODUCT
SET STANDARD_COST = 55.35,
    LIST_PRICE = 67.55
FROM PRODUCT
JOIN  CTE__ProductsToUpdate
ON PRODUCT.PRODUCT_ID = CTE__ProductsToUpdate.PRODUCT_ID
WHERE  CTE__ProductsToUpdate.PRODUCT_NAME = 'Flat Washer 1';
-----------------------------------------------------------------------------------
-----------------------------------------------------------------------------------

/*
Make a query that shows the count of employee by job title per department. Sort the
query by Department Name. The query should have the following columns:
a. DEPARTMENT NAME
b. JOB TITLE
c. EMPLOYEE COUNT
*/


;WITH CTE_SHOW_EMPLOYEE_COUNT AS (
	SELECT D.DEPT_NAME AS "DEPARTMENT NAME" ,E.JOBTITLE AS "JOBTITLE",E.PERSONID AS "EMPOLOYEE COUNT"
	FROM 
	[HR_TINOY2].[dbo].[DEPARTMENT] D
	INNER JOIN [HR_TINOY2].[dbo].EMPLOYEE E ON D.DEPARTMENT_ID = E.PERSONID	
)
SELECT *
FROM CTE_SHOW_EMPLOYEE_COUNT
ORDER BY "DEPARTMENT NAME";
-----------------------------------------------------------------------------------
---------------------------WALA NAKO KASABOT MAAM --------------------------------------------------------
/*
Make a query that shows the annual Total Sales by Vendor based on the year of order
from 2010 to 2015. The Total Sales is the sum of sub total + freight + tax amount. Sort
the query by Vendor Name. When no sales found for the said Vendor return the Total
Sales to 0.00. Round the Total Sales into 2 decimal places. The query should have the
following columns:
a. VENDOR NAME
b. YR2010_TOTALSALES
c. YR2011_TOTALSALES
d. YR2012_TOTALSALES
e. YR2013_TOTALSALES
f. YR2014_TOTALSALES
g. YR2015_TOTALSALES
*/

WITH SalesByYear AS (
    SELECT
        V.VENDOR_NAME,
        YEAR(PH.ORDERDATE) AS ORDER_YEAR,
        ROUND(SUM(PH.SUBTOTAL + PH.FREIGHT + PH.TAXAMOUNT), 2) AS TOTAL_SALES
    FROM PURCHASEORDERHEADER PH
    INNER JOIN VENDOR V ON PH.VENDOR_ID = V.VENDOR_ID
    GROUP BY
        V.VENDOR_NAME, YEAR(PH.ORDERDATE)
)
SELECT * FROM SalesByYear WHERE ORDER_YEAR ='2010'

---------------------------------------------------------------------------------
---------------------------------------------------------------------------------
/*
4. Make a that query that shows the Total Rates by Department and Total Rates by Group
Name. Sort the query by Department Name and Group Name. The query should have
the following columns:
a. DEPARTMENT NAME
b. DEPARTMENT RATES
c. GROUP NAME
d. GROUP RATES
*/
;WITH CTE_TOTAL_RATES AS (
	SELECT D.DEPT_NAME AS "DEPARTMENT NAME",
		EPH.RATE AS "DEPARTMENT RATE",
		D.GROUPNAME,
		EPH.RATE AS "GROUP NAME RATE"
		FROM
		[HR_TINOY2].[dbo].[DEPARTMENT] D
		INNER JOIN [HR_TINOY2].[dbo].EMPLOYEE E ON D.DEPARTMENT_ID = E.PERSONID
		JOIN [HR_TINOY2].[dbo].[EMPLOYEEPAYHISTORY] EPH ON EPH.PERSONID=E.PERSONID
)
SELECT GROUPNAME FROM[HR_TINOY2].[dbo].[DEPARTMENT]