use [HR_TINOY2]
GO 
SELECT * FROM  [dbo].[EMPLOYEE]
/*Make a query that shows the employee by Department. The query should have the
following columns. Sort the query by Department Name and Employee Name in
ascending.
a. Department Name
b. Employee Name � should be concatenated from employee first name and employee
last name
c. Job Title
d. Shift � should be the shift name
e. Rate*/
SELECT
    D.DEPT_NAME AS [Department Name],
    CONCAT(P.FIRSTNAME, ' ', P.LASTNAME) AS [Employee Name],
    E.JOBTITLE AS [Job Title],
    S.[NAME] AS [Shift],
    EP.RATE AS [Rate]
FROM
    DEPARTMENT D
INNER JOIN
    EMPLOYEEDEPARTMENTHISTORY EDH ON D.DEPARTMENT_ID = EDH.DEPARTMENT_ID
INNER JOIN
    EMPLOYEE E ON EDH.PERSONID = E.PERSONID
INNER JOIN
    PERSON P ON E.PERSONID = P.PERSONID
INNER JOIN
    [SHIFT] S ON EDH.SHIFTID = S.SHIFTID
INNER JOIN
    EMPLOYEEPAYHISTORY EP ON E.PERSONID = EP.PERSONID
ORDER BY
    [Department Name] ASC,
    [Employee Name] ASC;

/*Make a query that shows the employee who has the rate of greater than or equal to 20
but less than or equal to 45. Sort the query by employee name in ascending. The query
should have the following columns:
a. Employee Name - should be concatenated from employee first name and employee
last name
b. Rate*/
SELECT 
CONCAT(p.FIRSTNAME, ' ', p.LASTNAME) AS 'Employee Name',
EH.RATE AS 'Rate'
FROM EMPLOYEEPAYHISTORY EH
INNER JOIN PERSON p ON EH.PERSONID = p.PERSONID
WHERE EH.RATE >= 20 AND EH.RATE <= 45
ORDER BY 'Employee Name' ASC;

/*Make a query that shows the total salary rate by Department. Group the query by
Department Name and sort by Department Name in descending. The query should have
the following columns:
a. Department Name
b. Total Rate*/
SELECT 
d.DEPT_NAME AS 'Department Name',
SUM(eh.RATE) AS 'Total Rate'
FROM DEPARTMENT d
LEFT JOIN EMPLOYEE e ON d.DEPARTMENT_ID = e.PERSONID
LEFT JOIN EMPLOYEEPAYHISTORY eh ON e.PERSONID = eh.PERSONID
GROUP BY d.DEPT_NAME
ORDER BY 'Department Name' DESC;

/*Make a query that shows the Employee who doesn�t have a Title or the Employee with
Title = �Ms. �and Employee who is not promoted and the person type = �EM�. Sort the
query by Employee Last Name. The query should have the following columns:
a. Title
b. Employee Last Name
c. Employee First Name
d. Job Title
e. Birth Date
f. Hire Date
g. Marital Status � this should display the description not the initial like M for Married
and S-Single
h. Gender � this should display the description not the initial like M for Male and F for
Female
i. Person Type
j. Email Promotion
*/
SELECT 
    p.TITLE,
    p.LASTNAME AS 'Employee Last Name',
    p.FIRSTNAME AS 'Employee First Name',
    e.JOBTITLE AS 'Job Title',
    e.BIRTHDATE AS 'Birth Date',
    e.HIREDATE AS 'Hire Date',
    ISNULL(NULLIF(e.MARITALSTATUS, 'S'), 'Married') AS 'Marital Status',
    ISNULL(NULLIF(e.GENDER, 'M'), 'Female') AS 'Gender',
    p.PERSONTYPE AS 'Person Type'
FROM PERSON p
LEFT JOIN EMPLOYEE e ON p.PERSONID = e.PERSONID
WHERE (p.TITLE = 'Ms. ' OR p.TITLE IS NULL)
    AND p.PERSONTYPE = 'EM'
ORDER BY p.LASTNAME;















EXEC SP_INSRT_DEPARTMENT 'Engineering', 'Research and Development';
EXEC SP_INSRT_DEPARTMENT 'Tool Design', 'Research and Development';
EXEC SP_INSRT_DEPARTMENT 'Sales', 'Sales and Marketing';
EXEC SP_INSRT_DEPARTMENT 'Marketing', 'Sales and Marketing';
EXEC SP_INSRT_DEPARTMENT 'Purchasing', 'Inventory Management';
EXEC SP_INSRT_DEPARTMENT 'Research and Development', 'Research and Development';
EXEC SP_INSRT_DEPARTMENT 'Production', 'Manufacturing';
EXEC SP_INSRT_DEPARTMENT 'Production Control', 'Manufacturing';
EXEC SP_INSRT_DEPARTMENT 'Human Resources', 'Executive General and Administration';
EXEC SP_INSRT_DEPARTMENT 'Finance', 'Executive General and Administration';
EXEC SP_INSRT_DEPARTMENT 'Information Services', 'Executive General and Administration';
EXEC SP_INSRT_DEPARTMENT 'Document Control', 'Quality Assurance';
EXEC SP_INSRT_DEPARTMENT 'Quality Assurance', 'Quality Assurance';
EXEC SP_INSRT_DEPARTMENT 'Facilities and Maintenance', 'Executive General and Administration';
EXEC SP_INSRT_DEPARTMENT 'Shipping and Receiving', 'Inventory Management';
EXEC SP_INSRT_DEPARTMENT 'Executive', 'Executive General and Administration'


EXEC [dbo].[SP_PERSON] 'EM', 0, NULL, 'Ken J', 'S�nchez', NULL, 0
EXEC [dbo].[SP_PERSON] 'EM', 0, NULL, 'Terri Lee', 'Duffy', NULL, 1
EXEC [dbo].[SP_PERSON]'EM', 0, NULL, 'Roberto', 'Tamburello', NULL, 0
EXEC [dbo].[SP_PERSON]'EM', 0, NULL, 'Rob', 'Walters', NULL, 0
EXEC [dbo].[SP_PERSON]'EM', 0, 'Ms.', 'Gail A', 'Erickson', NULL, 0
EXEC [dbo].[SP_PERSON]'EM', 0, 'Mr.', 'Jossef H', 'Goldberg', NULL, 0
EXEC [dbo].[SP_PERSON]'EM', 0, NULL, 'Dylan A', 'Miller', NULL, 2
EXEC [dbo].[SP_PERSON]'EM', 0, NULL, 'Diane L', 'Margheim', NULL, 0
EXEC [dbo].[SP_PERSON]'EM', 0, NULL, 'Gigi N', 'Matthew', NULL, 0
EXEC [dbo].[SP_PERSON]'EM', 0, NULL, 'Michael', 'Raheem', NULL, 2

EXEC SP_EMPLOYEE 1, 'Chief Executive Officer', '1969-01-29', 'S', 'M', '2009-01-14', '1', '99', '69', '1';
EXEC SP_EMPLOYEE 2, 'Vice President of Engineering', '1971-08-01', 'S', 'F', '2008-01-31', '1', '1', '20', '1';
EXEC SP_EMPLOYEE 3, 'Engineering Manager', '1974-11-12', 'M', 'M', '2007-11-11', '1', '2', '21', '1';
EXEC SP_EMPLOYEE 4, 'Senior Tool Designer', '1974-12-23', 'S', 'M', '2007-12-05', '0', '48', '80', '1';
EXEC SP_EMPLOYEE 5, 'Design Engineer', '1952-09-27', 'M', 'F', '2008-01-06', '1', '5', '22', '1';
EXEC SP_EMPLOYEE 6, 'Design Engineer', '1959-03-11', 'M', 'M', '2008-01-24', '1', '6', '23', '1';
EXEC SP_EMPLOYEE 7, 'Research and Development Manager', '1987-02-24', 'M', 'M', '2009-02-08', '1', '61', '50', '1';
EXEC SP_EMPLOYEE 8, 'Research and Development Engineer', '1986-06-05', 'S', 'F', '2008-12-29', '1', '62', '51', '1';
EXEC SP_EMPLOYEE 9, 'Research and Development Engineer', '1979-01-21', 'M', 'F', '2009-01-16', '1', '63', '51', '1';
EXEC SP_EMPLOYEE 10, 'Research and Development Manager', '1984-11-30', 'M', 'M', '2009-05-03', '1', '16', '64', '1';