INSERT INTO VENDOR(
	ACCOUNT_NUM ,
	VENDOR_NAME ,
	ACTIVE_FLAG ) 
	VALUES	('MORGANB0001', 'Morgan Bike Accessories',1),
			('MOUNTAIN0001', 'Mountain Work', 1),
			('READYRE0001', 'Ready Rentals', 1),
			('RELIANCE0001', 'Reliance Fitness Inc.', 0),
			('SIGNATUR0001', 'Signature Cycles', 1),
			('SPORTFA0001', 'Sport Fan Co.', 1),
			('SPORTPL0001', 'Sport Playground', 1),
			('SUPERIOR0001', 'Superior Bicycles', 1),
			('SUPERSAL0001', 'SUPERSALES INC.', 1)
SELECT * FROM VENDOR
-------------------------------------------------------------------
-------------------------------------------------------------------
INSERT INTO PRODUCT(
	PRODUCT_NAME,
	PRODUCT_NUMBER,
	COLOR,
	STANDARD_COST,
	LIST_PRICE )
	VALUES
		('Rear Brakes',' RB-9231 ','Silver', 47.286 ,106.5),
		('LL Mountain Tire ','TI-M267', NULL, 9.3463 ,24.99),
		('ML Mountain Tire',' TI-M602 ',NULL, 11.2163, 29.99),
		('HL Mountain Tire ','TI-M823 ',NULL, 13.09, 35),
		('LL Road Tire ','TI-R092', NULL, 8.0373 ,21.49),
		('ML Road Tire',' TI-R628 ',NULL, 9.3463 ,24.99),
		('ML Road Tire',' TI-R628',NULL, 9.3463 ,24.99),
		('HL Road Tire',' TI-R982', NULL, 12.1924, 32.6),
		('Freewheel',' FH-2981',' Silver', 0, 0),
		('Flat Washer 1','FW-1000', NULL, 0, 0)
-------------------------------------------------------------------
-------------------------------------------------------------------
INSERT INTO PURCHASEORDERHEADER(
	ORDERDATE,
	SHIPDATE,
	VENDOR_ID,
	SUBTOTAL,
	TAXAMOUNT,
	FREIGHT)
	VALUES
		('2014-09-22','2014-10-17', 1, 45558.98, 81.6, 20.4),
		('2014-01-03','2014-01-12', 7, 21869.93, 4967.424, 1552.32),
		('2011-08-03','2011-08-10', 8, 24191.48, 475.86, 148.7063),
		('2010-08-03','2010-08-12', 9, 124.1415, 7289.436, 2277.949),
		('2009-08-03','2009-08-15', 4, 136.962,33.3396, 10.4186),
		('2012-09-03','2012-09-12', 2, 124.1415, 33.516, 10.4738),
		('2013-09-03','2013-10-12', 5, 142.947, 22.3322, 6.9788),
		('2014-08-06','2014-08-13', 3, 18890.03, 42.0613, 13.1442),
		('2015-08-04','2015-08-12', 10, 21581.18, 42, 13.125),
		('2016-08-05','2016-08-12', 6, 142.4115, 3237.696, 1011.78)
SELECT * FROM PURCHASEORDERHEADER
	
INSERT INTO PURCHASEORDERDETAIL(
	PURCHASEORDERID,
	PRODUCT_ID ,
	ORDERQTY,
	UNITPRICE)
	VALUES
			(1,1, 550, 82.8345),
			(2,6, 550, 39.7635),
			(3,8, 550, 43.9845),
			(4,9, 3, 41.3805),
			(5,3, 3, 45.654),
			(6,3, 3, 41.3805),
			(7,10, 3, 47.649),
			(8,5, 550, 34.3455),
			(9,7, 550, 39.2385),
			(10,10, 3, 47.4705)
DELETE FROM PURCHASEORDERDETAIL
DBCC CHECKIDENT('PURCHASEORDERDETAIL',RESEED,0)
SELECT * FROM PURCHASEORDERDETAIL
------------------------------------------------------------
/*3. Make a query that shows the list of Products with Purchase Order by Vendor. Sort the
list by Vendor Name and Product Name in chronological order. The list should have the
following columns.
a. Vendor name
b. Product name
c. Total Order Quantity */
SELECT
    V.VENDOR_NAME ,
    P.PRODUCT_NAME ,
    D.ORDERQTY 
FROM
    VENDOR V
INNER JOIN
    PURCHASEORDERHEADER POH ON V.VENDOR_ID = POH.VENDOR_ID
INNER JOIN
    PURCHASEORDERDETAIL D ON POH.PURCHASEORDERID = D.PURCHASEORDERID
INNER JOIN
    PRODUCT P ON D.PRODUCT_ID = P.PRODUCT_ID
ORDER BY
    V.VENDOR_NAME,
    P.PRODUCT_NAME;


/*4. Make a query that shows the list of products that exists in Purchase Order where the
order date year is greater than or equal to 2011. Sort the product list by Product Name in
ascending order. The list should have the following columns:
a. Product Name
b. Product Number
c. Color
d. List Price
e. Standard Cost*/
SELECT
    P.PRODUCT_NAME,
    P.PRODUCT_NUMBER,
    P.COLOR,
    P.LIST_PRICE,
    P.STANDARD_COST
FROM
    PRODUCT P
INNER JOIN
    PURCHASEORDERDETAIL D ON P.PRODUCT_ID = D.PRODUCT_ID
INNER JOIN
    PURCHASEORDERHEADER H ON D.PURCHASEORDERID = H.PURCHASEORDERID
WHERE
    YEAR(H.ORDERDATE) >= 2011
ORDER BY
    P.Product_Name ASC;


/*5. Make a query that shows the unique orders with the lowest freight cost where Ship Date
is less than or equal to �2012-01-25�. The query should have the following columns:
a. Product Name
b. Order Quantity
c. Unit Price
d. Line Total*/
SELECT
    P.PRODUCT_NAME,
    D.ORDERQTY,
    D.UNITPRICE,
    D.LINETOTAL
FROM
    PURCHASEORDERDETAIL D
INNER JOIN
    PRODUCT P ON D.PRODUCT_ID = P.PRODUCT_ID
INNER JOIN
    PURCHASEORDERHEADER H ON D.PURCHASEORDERID = H.PURCHASEORDERID
WHERE
    H.SHIPDATE <= '2012-01-25'
    AND H.FREIGHT = (
        SELECT MIN(FREIGHT)
        FROM PURCHASEORDERHEADER
        WHERE SHIPDATE <= '2012-01-25');
/*6. Make a query that shows the top 3 selling vendors. The query should have the following
columns:
a. Vendor Name
b. Total Sales*/
SELECT TOP 3
    V.VENDOR_NAME,
    D.LINETOTAL
FROM
    VENDOR V
INNER JOIN
    PURCHASEORDERHEADER POH ON V.VENDOR_ID = POH.VENDOR_ID
INNER JOIN
    PURCHASEORDERDETAIL D ON POH.PURCHASEORDERID = D.PURCHASEORDERID
ORDER BY
    D.LINETOTAL DESC;
/*7. Make a query the shows the total sales by year. Sort the query by year. Do not include
the Tax Amount and Freight Cost.The query should have the following columns:
a. Year
b. Total Sales*/
SELECT
    ORDERDATE,
    SUBTOTAL
FROM
    PURCHASEORDERHEADER
ORDER BY
    ORDERDATE;


UPDATE PURCHASEORDERDETAIL
SET UNITPRICE = 65.0053
WHERE PRODUCT_ID = (
    SELECT PRODUCT_ID
    FROM PRODUCT
    WHERE PRODUCT_NAME = 'Rear Brakes'
)
AND PURCHASEORDERID IN (
    SELECT PH.PURCHASEORDERID
    FROM PURCHASEORDERHEADER PH
    JOIN VENDOR V ON PH.VENDOR_ID = V.VENDOR_ID
    WHERE PH.ORDERDATE = '2014-09-22' AND V.VENDOR_NAME = 'Jeff''s Sporting Goods'
);
UPDATE PURCHASEORDERHEADER
SET SUBTOTAL = (
    SELECT SUM(D.UNITPRICE * D.ORDERQTY)
    FROM PURCHASEORDERDETAIL D
    WHERE D.PURCHASEORDERID = PURCHASEORDERHEADER.PURCHASEORDERID
)
WHERE PURCHASEORDERID IN (
    SELECT PH.PURCHASEORDERID
    FROM PURCHASEORDERHEADER PH
    JOIN VENDOR V ON PH.VENDOR_ID = V.VENDOR_ID
    WHERE PH.ORDERDATE = '2014-09-22' AND V.VENDOR_NAME = 'Jeff''s Sporting Goods'
);


/*9. Make a query that shows the first 2 saleable products. The query should have the
following columns:
a. Product Name
b. Total Order*/
SELECT TOP 2
    P.PRODUCT_NAME,
    D.ORDERQTY 
FROM
    PRODUCT P
LEFT JOIN
    PURCHASEORDERDETAIL D ON P.PRODUCT_ID = D.PRODUCT_ID
ORDER BY
    D.ORDERQTY DESC;