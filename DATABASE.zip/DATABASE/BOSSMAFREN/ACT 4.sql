USE PUT_TINOY2
GO

CREATE PROCEDURE SP_PRODNUM_FILTER
(
	@PRODNUMBER CHAR(2) = NULL
)
AS 
SELECT coalesce([PRODUCT_NUMBER],'') as PRODUCT_NUMBER, isnull(PRODUCT_NUMBER,'')
as Title2,[PRODUCT_NAME],[STANDARD_COST],[LIST_PRICE]
from [dbo].[PRODUCT]
where LEFT(PRODUCT_NUMBER,2) = coalesce(@PRODNUMBER,LEFT(PRODUCT_NUMBER,2))
ORDER BY
PRODUCT_NUMBER,
PRODUCT_NAME; 
EXEC SP_PRODNUM_FILTER 'TI'
-----------------------------------------------------------------------------
-----------------------------------------------------------------------------
USE PUR_TINOY;
CREATE PROCEDURE SP_GET_EMPLOYEES_BY_DEPARTMENT
    @DEPARTMENTNAME VARCHAR(100) = NULL
AS
BEGIN
    SELECT 
        UPPER(d.DEPT_NAME) AS 'Department Name',
        UPPER(CONCAT(p.FIRSTNAME, ' ', p.LASTNAME)) AS 'Employee Name',
        UPPER(e.JOBTITLE) AS 'Job Title',
        REPLACE('*************', ' ', '') AS 'Birth Date', 
        REPLACE(CONVERT(NVARCHAR(10), e.HIREDATE, 101), '-', '/') AS 'Hire Date', 
        REPLACE(CONVERT(NVARCHAR(10), COALESCE(edh.STARTDATE, '1900-01-01'), 101), '-', '/') AS 'Start Date', 
        REPLACE(CONVERT(NVARCHAR(10), COALESCE(edh.ENDDATE, '1900-01-01'), 101), '-', '/') AS 'End Date', 
        COALESCE(e.VACATIONHOURS, 0) AS 'Vacation Hours',
        COALESCE(e.SICKLEAVEHOURS, 0) AS 'Sick Leave Hours',
        REPLACE(REPLACE(e.MARITALSTATUS, 'S', 'Single'), 'M', 'Married') AS 'Marital Status',
        REPLACE(REPLACE(e.GENDER, 'M', 'Male'), 'F', 'Female') AS 'Gender' 
    FROM HR_TINOY.DBO.DEPARTMENT d
    INNER JOIN HR_TINOY.DBO.PERSON p ON d.DEPARTMENT_ID = p.PERSONID
    LEFT JOIN HR_TINOY.DBO.EMPLOYEE e ON p.PERSONID = e.PERSONID
    LEFT JOIN HR_TINOY.DBO.EMPLOYEEDEPARTMENTHISTORY edh ON p.PERSONID = edh.PERSONID
    WHERE @DEPARTMENTNAME IS NULL OR UPPER(d.DEPT_NAME) = UPPER(@DEPARTMENTNAME)
    ORDER BY 'Department Name', 'Employee Name';
END

EXEC SP_GET_EMPLOYEES_BY_DEPARTMENT "RESEARCH AND DEVELOPMENT"
SELECT * FROM [HR_TINOY2].[dbo].[DEPARTMENT]
-----------------------------------------------------------------------------
-----------------------------------------------------------------------------
CREATE PROCEDURE SP_GET_VENDOR_PRODUCTS
    @VENDORNAME VARCHAR(100) = NULL
AS
BEGIN
    SELECT 
        UPPER(v.VENDOR_NAME) AS 'Vendor Name',
        REPLACE(v.ACCOUNT_NUM, SUBSTRING(v.ACCOUNT_NUM, 9, 5), '****') AS 'Account Number', 
        UPPER(ISNULL(p.PRODUCT_NAME, 'UNKNOWN')) AS 'Product Name', 
        CONVERT(NVARCHAR(10), po.ORDERDATE, 101) AS 'Order Date', 
        ROUND(COALESCE(po.TOTALDUE, 0.00), 2) AS 'Total Due' 
    FROM VENDOR v
    LEFT JOIN PURCHASEORDERHEADER po ON v.VENDOR_ID = po.VENDOR_ID
    LEFT JOIN PURCHASEORDERDETAIL pod ON po.PURCHASEORDERID = pod.PURCHASEORDERID
    LEFT JOIN PRODUCT p ON pod.PRODUCT_ID = p.PRODUCT_ID
    WHERE @VENDORNAME IS NULL OR UPPER(v.VENDOR_NAME) = UPPER(@VENDORNAME)
    ORDER BY 'Vendor Name', 'Product Name';
END
EXEC SP_GET_VENDOR_PRODUCTS 'Sport Playground '  
SELECT * FROM VENDOR




