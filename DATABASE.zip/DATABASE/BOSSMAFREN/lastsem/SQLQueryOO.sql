CREATE TABLE ORDrr
(
 ORDERID int NOT NULL IDENTITY(1,1),
 CookiesOrdered int NOT NULL,
 BoxQuantity int NOT NULL, 
 ContainerQunatity int NOT NULL,
 TotalBoxes int NOT NULL, 
 TotalContainer int NOT NULL,
)
GO 