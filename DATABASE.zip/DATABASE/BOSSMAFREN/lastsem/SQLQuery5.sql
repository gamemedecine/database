---
--8 Make a query that shows the total product on hand by vendor
---
USE SALES
select P.PROD_ONHAND,V.VENDOR_NAME
FROM PRODUCT P
JOIN VENDOR V
ON P.VEND_CODE=V.VENDOR_CODE

---
--9 Make a query that shows the total average product price by vendor
---
SELECT vendors.vendor_name, AVG(.product_price) AS avg_price
FROM products
INNER JOIN vendors ON products.vendor_name = vendors.vendor_name
WHERE products.product_price IS NOT NULL

SELECT VENDOR_NAME, AVG(PROD_PRICE) AS avg_price
FROM PRODUCT
WHERE PROD_PRICE IS NOT NULL


SELECT Vendors.Name AS VendorName, AVG(Products.Price) AS AvgPrice
FROM Products
INNER JOIN Vendors ON Products.VendorID = Vendors.ID
GROUP BY Vendors.Name