CREATE DATABASE MOTORPARTS;

CREATE TABLE Seller (
    seller_id INT PRIMARY KEY not null,
    seller_name VARCHAR(60) not null,
	seler_number varchar(11) not null,
	seller_email varchar(20) not null
);
 create INDEX idx_seller_name on seller(seller_name) 


CREATE TABLE Product (
    product_id INT PRIMARY KEY,
    product_name VARCHAR(50),
    product_price DECIMAL(10, 2),
    seller_id INT,
    FOREIGN KEY (seller_id) REFERENCES Seller(seller_id)
);
create index idx_product_name on product(product_name)


USE MOTORPARTS
GO 
DROP TABLE  COSTUMER
CREATE TABLE  COSTUMER (
    COSTUMER_id INT PRIMARY KEY NOT NULL,
    COSTUMER_Fname VARCHAR(50) NOT NULL,
	COSTUMER_lname varchar NOT NULL,
	COSTUMER_fullname AS (CONCAT( COSTUMER_Fname, ' ', COSTUMER_lname)),
	COSTUMER_ADDRESS VARCHAR(60) NOT NULL,
	COSTUMER_email varchar(60) NOT NULL
);
create INDEX idx_customer_name on costumer(customer_Fname) 
create INDEX IDX_COSTUMER_LNAME ON COSTUMER(COSTUMER_LNAME)
CREATE INDEX IDX_COSTUMER_FULLNAME ON COSTUMER (COSTUMER_FULLNAME)

DROP TABLE [Order]
CREATE TABLE [Order] (
    order_id INT PRIMARY KEY,	
	COSTUMER_id INT,
    order_date DATE,
    FOREIGN KEY ( COSTUMER_id) REFERENCES  COSTUMER( COSTUMER_ID)
);

DROP TABLE OrderProduct
CREATE TABLE OrderProduct (
    order_id INT,
	COSTUMER_id INT,
    product_id INT,
    quantity INT,
	order_date DATE DEFAULT GETDATE(),
	FOREIGN KEY ( COSTUMER_id) REFERENCES  COSTUMER( COSTUMER_ID),
    FOREIGN KEY (product_id) REFERENCES Product(product_id)
);