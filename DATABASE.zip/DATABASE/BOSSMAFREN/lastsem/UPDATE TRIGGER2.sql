[ClassScheduling]
USE ClassScheduling
GO
/*TRIGGER*/
/*a) Course � when course description is null insert course title in course description */

CREATE TRIGGER tr_course_insert
ON Course AFTER INSERT
AS

BEGIN
	DECLARE @COURSE_TITLE VARCHAR(100)
	DECLARE @COURSE_DESC VARCHAR(10)

	SELECT @COURSE_DESC = COURSE_DESC, @COURSE_TITLE = Course_Title  FROM INSERTED;
	IF @COURSE_DESC IS NULL SET @COURSE_DESC = @COURSE_TITLE
	IF @COURSE_TITLE IS NULL SET @COURSE_TITLE = @COURSE_DESC
	INSERT INTO COUSRSE (COURSE_TITLE)
	VALUES(@COURSE_TITLE)
END;

/*b) Department � when department description is null insert department name in
department description.*/

crEATE TRIGGER tr_department_insert
ON Department INSTEAD OF INSERT
AS 
BEGIN
	DECLARE @DEPT_DESC VARCHAR(100)
	DECLARE @DEPT_NAME VARCHAR(10)
		
	SELECT @DEPT_DESC = DEPT_DESCRIPTION, @DEPT_NAME = DEPT_NAME  FROM INSERTED;
	IF @DEPT_DESC IS NULL SET @DEPT_DESC = @DEPT_NAME
	IF @DEPT_NAME IS NULL SET @DEPT_NAME = @DEPT_DESc
    INSERT INTO Department (DEPT_NAME)
	VALUES(@DEPT_NAME)
 END