DROP PROCEDURE sp_InsertDepartment
CREATE PROCEDURE sp_InsertDepartment
    @Dept_Name VARCHAR(10),
    @Dept_Description VARCHAR(100)
AS
BEGIN
    IF EXISTS (SELECT * FROM DEPARTMENT WHERE DEPT_NAME = @Dept_Name)
	BEGIN 
    UPDATE Department
	SET
	DEPT_NAME= UPPER(@Dept_Name),
	Date_Created=GETDATE()
	WHERE DEPT_NAME=@Dept_Name
	END 
	ELSE
	BEGIN 
		INSERT INTO DEPARTMENT(DEPT_NAME,Date_Created)
		VALUES(UPPER(@Dept_Name),GETDATE())
	END 
END;
EXEC sp_InsertDepartment 'MARINE','MARINE engineering';
SELECT * FROM DEPARTMENT
/*============================ROOM=====================================*/
DROP PROCEDURE InsertOrUpdateRoom
CREATE PROCEDURE InsertOrUpdateRoom
    @Room_Code INT = NULL,
    @Room_Type VARCHAR(10)
AS
BEGIN
    IF @Room_Code IS NULL
    BEGIN
        IF NOT EXISTS (SELECT * FROM Room WHERE Room_Type = @Room_Type)
        BEGIN
            INSERT INTO Room (Room_Type, Date_Created)
            VALUES (UPPER(@Room_Type), GETDATE())
        END
    END
    ELSE 
    BEGIN
        IF EXISTS (SELECT * FROM Room WHERE Room_Code = @Room_Code)
        BEGIN
            UPDATE Room
            SET Room_Type = UPPER(@Room_Type),
                Date_Created = GETDATE()
            WHERE Room_Code = @Room_Code
        END
    END
END;
EXEC InsertOrUpdateRoom @Room_Type = 'COMPUTER LAB'
SELECT * FROM ROOM
/*============================PROFESSOR=====================================*/
DROP PROCEDURE  UpsertProfessor 
CREATE PROCEDURE UpsertProfessor 
    @Dept_Code INT,
    @Prof_FName VARCHAR(15),
    @Prof_LName 
	VARCHAR(20),
    @isActive INT
AS
BEGIN
    IF EXISTS(SELECT 1 FROM Professor WHERE Prof_FullName = UPPER(@Prof_FName + ' ' + @Prof_LName))
    BEGIN
        UPDATE Professor 
        SET Dept_Code = @Dept_Code, 
            Prof_FName = UPPER(@Prof_FName), 
            Prof_LName = UPPER(@Prof_LName),
            isActive = @isActive
        WHERE Prof_FullName = UPPER(@Prof_FName + ' ' + @Prof_LName);
    END
    ELSE
    BEGIN
        INSERT INTO Professor (Dept_Code, Prof_FName, Prof_LName, isActive)
        VALUES (@Dept_Code, @Prof_FName, @Prof_LName, @isActive);
    END
END
EXEC UpsertProfessor 1,'DUENGA','DRILL',1
EXEC UpsertProfessor 2,'ford','nate',2
select * FROM PROFESSOR

/*============================STUDENT=====================================*/
DROP PROCEDURE InsertOrUpdateStudent
CREATE PROCEDURE InsertOrUpdateStudent
    @Stud_Num INT = NULL,
    @Dept_Code INT,
    @Stud_FName VARCHAR(15),
    @Stud_LName VARCHAR(20),
    @Prof_Num INT = NULL
AS
BEGIN
    IF @Stud_Num IS NULL
    BEGIN
        IF NOT EXISTS(SELECT 1 FROM Student WHERE Stud_FullName = UPPER(@Stud_FName + ' ' + @Stud_LName))
        BEGIN
            INSERT INTO Student (Dept_Code, Stud_FName, Stud_LName, Prof_Num)
            VALUES (
			@Dept_Code, 
			UPPER(@Stud_FName), 
			UPPER(@Stud_LName),
			@Prof_Num);
        END
    END
    ELSE
    BEGIN
        IF EXISTS(SELECT 1 FROM Student WHERE Stud_Num = @Stud_Num)
        BEGIN
            UPDATE Student 
            SET Dept_Code = @Dept_Code, 
                Stud_FName = UPPER(@Stud_FName), 
                Stud_LName = UPPER(@Stud_LName),
                Prof_Num = @Prof_Num
            WHERE Stud_Num = @Stud_Num;
        END
    END
END
EXEC InsertOrUpdateStudent 
	  @Dept_Code= 1
	  ,@Stud_FName='john' 
	  ,@Stud_LName='oresga'
	  ,@Prof_Num=2
select * FROM STUDENT

/*============================STUDENT=====================================*/
CREATE PROCEDURE InsertOrUpdateCourse
    @Course_Code INT = NULL,
    @Dept_Code INT,
    @Course_Title VARCHAR(20),
    @Course_Desc VARCHAR(100) = NULL,
    @Course_Credits INT
AS
BEGIN

    IF @Course_Code IS NULL
    BEGIN
        IF NOT EXISTS(SELECT 1 FROM Course WHERE Course_Title = @Course_Title AND Dept_Code = @Dept_Code)
        BEGIN
            INSERT INTO Course (Dept_Code, Course_Title, Course_Desc, Course_Credits)
            VALUES (@Dept_Code, @Course_Title, @Course_Desc, @Course_Credits);
        END
    END
    ELSE 
    BEGIN
        IF EXISTS(SELECT 1 FROM Course WHERE Course_Code = @Course_Code)
        BEGIN
            UPDATE Course 
            SET Dept_Code = @Dept_Code, 
                Course_Title = @Course_Title, 
                Course_Desc = @Course_Desc,
                Course_Credits = @Course_Credits
            WHERE Course_Code = @Course_Code;
        END
    END
END
EXEC InsertOrUpdateCourse 
	@Dept_Code = 1,
	@Course_Title ='IT',
    @Course_Desc ='INFORAMTION TECHNOLOGY',
	@Course_Credits =24
SELECT * FROM COURSE

/*============================CLASS=====================================*/
DROP PROCEDURE InsertOrUpdateClass

CREATE PROCEDURE InsertOrUpdateClass
(
    @Class_Section VARCHAR(100),
    @Class_Date DATETIME,
    @Class_Strt_Time TIME,
    @Class_End_Time TIME,
    @Course_Code INT,
    @Prof_Num INT,
    @Room_Code INT,
    @Stud_Num INT
)
AS
BEGIN
    IF EXISTS (SELECT * FROM Class WHERE Class_Section = @Class_Section)
    BEGIN
        UPDATE Class
        SET Class_Section = @Class_Section,
            Class_Date = @Class_Date,
            Class_Strt_Time = @Class_Strt_Time,
            Class_End_Time = @Class_End_Time,
            Course_Code = @Course_Code,
            Prof_Num = @Prof_Num,
            Room_Code = @Room_Code,
            Stud_Num = @Stud_Num,
            Date_Created = GETDATE()
        WHERE Class_Section = @Class_Section
    END
    ELSE
    BEGIN
        INSERT INTO Class (
		Class_Section,
		Class_Date,
		Class_Strt_Time,
		Class_End_Time,
		Course_Code,
		Prof_Num, 
		Room_Code,
		Stud_Num
		)
        VALUES (
		@Class_Section,
		@Class_Date,
		@Class_Strt_Time,
		@Class_End_Time,
		@Course_Code,
		@Prof_Num, 
		@Room_Code,
		@Stud_Num
		)

   END
END
EXEC  InsertOrUpdateClass 'ATIS','2023-01-22 7:30:00','8:00:00','10:00:00',1,1,1,1