CREATE PROCEDURE GetClassesByDateRange
(
    @class_date_from DATE,
    @class_date_to DATE
)
AS
BEGIN
    SELECT 
        Class_Code, 
        Class_Section, 
        CAST(Class_Date AS DATE) AS Class_Date,
        Course_Code,
        Prof_Num,
        Room_Code,
        Stud_Num
    FROM 
        Class
    WHERE 
        CAST(Class_Date AS DATE) BETWEEN @class_date_from AND @class_date_to
        AND isActive = 1
    ORDER BY 
        Class_Date
END
EXEC GetClassesByDateRange '2023-04-01', '2023-04-30'

/*=============================================================*/
CREATE PROCEDURE GetClasses
    @class_date_from DATE,
    @class_date_to DATE
AS
BEGIN
    SELECT 
        r.Room_Type, 
        c.Course_Title, 
        cl.Class_Section, 
        CONCAT(p.First_Name, ' ', p.Last_Name) AS Professor_Full_Name
    FROM 
        Class cl
        INNER JOIN Room r ON cl.Room_Code = r.Room_Code
        INNER JOIN Course c ON cl.Course_Code = c.Course_Code
        INNER JOIN Professor p ON cl.Prof_Num = p.Prof_Num
    WHERE 
        cl.Class_Date BETWEEN @class_date_from AND @class_date_to
END
 you named it differently.






/*-==================================================*/
CREATE FUNCTION GetStudentsByCourse (@course_code INT)
RETURNS TABLE
AS
RETURN
    SELECT DISTINCT s.Stud_Num, s.Stud_FullName
    FROM Student s
    JOIN Class c ON s.Stud_Num = c.Stud_Num
    WHERE c.Course_Code = @course_code OR @course_code IS NULL;

SELECT * FROM GetStudentsByCourse(NULL); 
SELECT * FROM GetStudentsByCourse(1);

CREATE FUNCTION GetStudentsByCourseB
(
    @CourseCode INT = NULL
)
RETURNS TABLE
AS
RETURN
(
    SELECT DISTINCT 
        s.Stud_FullName AS Student_Full_Name
    FROM 
        Class c
        INNER JOIN Student s ON c.Stud_Num = s.Stud_Num
    WHERE 
        (@CourseCode IS NULL OR c.Course_Code = @CourseCode)
)
SELECT * FROM GetStudentsByCourseB(1234)
SELECT * FROM GetStudentsByCourseB()