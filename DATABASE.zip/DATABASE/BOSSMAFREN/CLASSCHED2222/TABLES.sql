CREATE DATABASE ClassScheduling
USE ClassScheduling
CREATE TABLE Department (
    Dept_Code INT  PRIMARY KEY IDENTITY,
    Dept_Name VARCHAR(10) NOT NULL,
    Dept_Description VARCHAR(100) NULL,
    Date_Created DATETIME NOT NULL DEFAULT GETDATE()
);
USE ClassScheduling
CREATE INDEX idx_Dept_Name ON Department (Dept_Name);
INSERT INTO Department(Dept_Name,Dept_Description) VALUES('BSCRIM',NULL)

SELECT * FROM Department
USE ClassScheduling
CREATE TABLE Room (
    Room_Code INT  PRIMARY KEY IDENTITY,
    Room_Type VARCHAR(10) NOT NULL,
    Date_Created DATETIME NOT NULL DEFAULT GETDATE()
);

INSERT INTO ROOM(Room_Type) VALUES(NULL,'COMPUTER LAB')
DROP INDEX idx_Room_Type ON Room
CREATE INDEX idx_Room_Type ON Room (Room_Type);
USE ClassScheduling
CREATE TABLE Professor (
    Prof_Num INT PRIMARY KEY IDENTITY,
    Dept_Code INT references Department NOT NULL,
    Prof_FName VARCHAR(15) NOT NULL,
    Prof_LName VARCHAR(20) NOT NULL,
    Prof_FullName AS UPPER(Prof_FName + ' ' + Prof_LName),
    Date_Created DATETIME DEFAULT GETDATE(),
    isActive INT DEFAULT 1 not null
);

CREATE  INDEX idx_Prof_LName ON Professor (Prof_LName);
USE ClassScheduling
CREATE TABLE Student (
    Stud_Num INT PRIMARY KEY IDENTITY,
    Dept_Code INT REFERENCES Department NOT NULL,
    Stud_FName VARCHAR(15) NOT NULL,
    Stud_LName VARCHAR(20) NOT NULL,
    Stud_FullName AS UPPER(Stud_FName + ' ' + Stud_LName),
    Date_Created DATETIME NOT NULL DEFAULT GETDATE(),
    Prof_Num int REFERENCES Professor
);
USE ClassScheduling
DROP INDEX idx_Stud_LName ON Student
CREATE  INDEX idx_Stud_LName ON Student (Stud_LName)
USE ClassScheduling
CREATE TABLE Course (
    Course_Code INT PRIMARY KEY IDENTITY,
    Dept_Code INT  REFERENCES Department NOT NULL,
    Course_Title VARCHAR(20) NOT NULL,
    Course_Desc VARCHAR(100) NULL,
    Course_Credits INT NOT NULL,
    Date_Created DATETIME NOT NULL DEFAULT GETDATE()
);
USE ClassScheduling
DROP INDEX idx_Course_Title ON Course
CREATE INDEX idx_Course_Title ON Course (Course_Title);
USE ClassScheduling
CREATE TABLE Class (
    Class_Code INT PRIMARY KEY IDENTITY,
    Class_Section VARCHAR(100) NOT NULL,
    Class_Date DATETIME NOT NULL,
    Class_Strt_Time TIME NOT NULL,
    Class_End_Time TIME NOT NULL,
    Course_Code INT  REFERENCES Course(Course_Code) not null,
    Prof_Num  int REFERENCES Professor not null,
    Room_Code INT REFERENCES Room not null,
    Stud_Num INT REFERENCES Student not null,
    Date_Created DATETIME DEFAULT GETDATE(),
    isActive INT  DEFAULT 1 not null
);

