[ClassScheduling]
/*TRIGGER*/
/*a) Course � when course description is null insert course title in course description */
CREATE TRIGGER tr_course_insert
ON Course AFTER INSERT
AS
BEGIN
  UPDATE Course
  SET Course_Desc = UPPER(Course_Title)
  WHERE Course_Code IS NULL
END;

/*b) Department � when department description is null insert department name in
department description.*/
DROP TRIGGER  tr_department_insert
CREATE TRIGGER tr_department_insert
ON Department AFTER INSERT
AS 
BEGIN
    UPDATE Department
    SET Dept_Description = UPPER(Dept_Name)
    WHERE Dept_Description IS NULL;
END; 

