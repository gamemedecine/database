
USE [PUT_TINOY2]
go
ALTER TABLE PURCHASEORDERHEADER
ADD EMPLOYEE_ID INT NULL
------------------------------------------------------------------------------UPDATE PURCHASEORDERHEADERSET EMPLOYEE_ID = E.PERSONIDFROM (	SELECT E.PERSONID FROM [HR_TINOY2].dbo.[EMPLOYEE] E	INNER JOIN [HR_tinoy2].dbo.[PERSON] P ON P.PERSONID = E.PERSONID	WHERE FIRSTNAME = 'Rob' AND LASTNAME = 'Walters') EWHERE YEAR(ORDERDATE) <= 2011SELECT * FROM PURCHASEORDERHEADER------------------------------------------------------------------------------vUPDATE PURCHASEORDERHEADERSET EMPLOYEE_ID = E.PERSONIDFROM(	SELECT E.PERSONID FROM [HR_TINOY2].dbo.[EMPLOYEE] E 	INNER JOIN [HR_TINOY2].dbo.[PERSON] P ON P.PERSONID = E.PERSONID	WHERE FIRSTNAME = 'Jossef' AND LASTNAME = 'Goldberg') EWHERE YEAR(ORDERDATE) >= 2012 AND YEAR(ORDERDATE) <= 2014SELECT * FROM PURCHASEORDERHEADER------------------------------------------------------------------------------UPDATE PURCHASEORDERHEADERSET EMPLOYEE_ID = E.PERSONIDFROM(	SELECT E.PERSONID FROM [HR_TINOY2].dbo.[EMPLOYEE] E 	INNER JOIN [HR_TINOY2].dbo.[PERSON] P ON P.PERSONID = E.PERSONID	WHERE FIRSTNAME = 'Diane' AND LASTNAME = 'Margheim') EWHERE YEAR(ORDERDATE) > 2014SELECT * FROM PURCHASEORDERHEADER
ALTER TABLE PURCHASEORDERHEADER
ALTER COLUMN EMPLOYEE_ID INT NOT NULL
-----------------------------------------------------------------------------
-----------------------------------------------------------------------------

--2.SELECT CONCAT(P.FIRSTNAME, ' ', P.LASTNAME) AS 'Employee Name'
       , E.JOBTITLE AS 'Job Title'
       , CAST(POH.ORDERDATE AS DATE) AS 'Order Date'
       , SUM(POD.LINETOTAL) AS 'Total Order'
FROM [HR_TINOY2].dbo.[EMPLOYEE] E
INNER JOIN [HR_TINOY2].dbo.[PERSON] P ON P.PERSONID = E.PERSONID
LEFT JOIN PURCHASEORDERHEADER POH ON POH.EMPLOYEE_ID = P.PERSONID
LEFT JOIN PURCHASEORDERDETAIL POD ON POD.PURCHASEORDERID = POH.PURCHASEORDERIDGROUP BY E.PERSONID, P.FIRSTNAME, P.LASTNAME, E.JOBTITLE, CAST(ORDERDATE AS DATE)ORDER BY 'Employee Name', 'Job Title'------------------------------------------------------------------------------------------------------------------------------------------------------------3.SELECT DEPT_NAME AS 'Department Name'
       , S.[NAME] AS 'Shift Name'
       , CONCAT(P.FIRSTNAME, ' ', P.LASTNAME) AS 'Employee Name'
FROM [HR_TINOY2].dbo.[DEPARTMENT] D
INNER JOIN [HR_TINOY2].dbo.[EMPLOYEEDEPARTMENTHISTORY] EDH ON EDH.DEPARTMENT_ID = D.DEPARTMENT_ID
INNER JOIN [HR_TINOY2].dbo.[SHIFT] S ON S.SHIFTID = EDH.SHIFTID
INNER JOIN [HR_TINOY2].dbo.[PERSON] P ON P.PERSONID = EDH.PERSONID
WHERE EDH.ENDDATE IS NOT NULL AND EDH.PERSONID IN 
(
	SELECT DISTINCT PERSONID
    FROM [HR_TINOY2].dbo.[EMPLOYEEDEPARTMENTHISTORY]
)
ORDER BY 'Department Name', 'Employee Name' ------------------------------------------------------------------------------------------------------------------------------------------------------------4.SELECT CONCAT(P.FIRSTNAME, ' ', P.LASTNAME) AS 'Employee Name'
       , DATEDIFF(YEAR, E.BIRTHDATE, GETDATE()) AS 'Age'
       , E.JOBTITLE AS 'Job Title'
       , CAST(E.HIREDATE AS DATE) AS 'Hire Date'
       , E.VACATIONHOURS AS 'Vacation Hours'
       , E.SICKLEAVEHOURS AS 'Sick Leave Hours'
FROM [HR_TINOY2].dbo.[PERSON] P 
INNER JOIN [HR_TINOY2].dbo.[EMPLOYEE] E ON E.PERSONID = P.PERSONID
WHERE E.BIRTHDATE IN 
(
	SELECT TOP 5 MIN(E.BIRTHDATE) AS MINBIRTHDATE
	FROM [HR_TINOY2].dbo.[EMPLOYEE] E
	GROUP BY PERSONID
	ORDER BY MINBIRTHDATE
)
ORDER BY 'Employee Name'------------------------------------------------------------------------------------------------------------------------------------------------------------5.SELECT V.VENDOR_NAME AS 'Vendor Name'
       , P.PRODUCT_NAME AS 'Product Name'
       , ROUND(ISNULL((POH.SUBTOTAL + POH.TAXAMOUNT + POH.FREIGHT), 0), 2) AS 'Total Due'
FROM VENDOR V
INNER JOIN PRODUCT P ON P.PRODUCT_ID = V.VENDOR_ID
LEFT JOIN PURCHASEORDERHEADER POH ON POH.VENDOR_ID = P.PRODUCT_ID
WHERE ACTIVE_FLAG = 1
ORDER BY 'Vendor Name', 'Product Name'------------------------------------------------------------------------------------------------------------------------------------------------------------6.SELECT DEPT_NAME AS 'Department Name'
       , D.GROUPNAME AS 'Group Name'
       , COUNT(E.PERSONID) AS 'Employees Id Count'
FROM  [HR_TINOY2].dbo.[DEPARTMENT] D
LEFT JOIN  [HR_TINOY2].dbo.[EMPLOYEE] E ON E.PERSONID = D.DEPARTMENT_ID
GROUP BY DEPT_NAME, D.GROUPNAME
ORDER BY 'Department Name'------------------------------------------------------------------------------------------------------------------------------------------------------------7.SELECT DEPT_NAME AS 'Department Name'
       , S.[NAME] AS 'Shift Name'
       , CONCAT(P.FIRSTNAME, ' ', P.LASTNAME) AS 'Employee Name'
       , E.JOBTITLE AS 'Job Title'
       , EPH.RATE AS 'Rate'
FROM [HR_TINOY2].dbo.[DEPARTMENT] D
INNER JOIN [HR_TINOY2].dbo.[EMPLOYEEDEPARTMENTHISTORY] EDH ON EDH.DEPARTMENT_ID = D.DEPARTMENT_ID
INNER JOIN [HR_TINOY2].dbo.[EMPLOYEEPAYHISTORY] EPH ON EPH.PERSONID = EDH.PERSONID
INNER JOIN [HR_TINOY2].dbo.[SHIFT] S ON S.SHIFTID = EDH.SHIFTID
INNER JOIN [HR_TINOY2].dbo.[PERSON] P ON P.PERSONID = EDH.PERSONID
INNER JOIN [HR_TINOY2].dbo.[EMPLOYEE] E ON E.PERSONID = P.PERSONID
INNER JOIN PURCHASEORDERHEADER POH ON POH.EMPLOYEE_ID = E.PERSONID
WHERE ORDERDATE >= '2013-01-01'
ORDER BY 'Department Name', 'Shift Name', 'Employee Name'