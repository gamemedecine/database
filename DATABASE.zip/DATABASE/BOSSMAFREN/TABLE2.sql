CREATE TABLE CustomerPurchaseHistory (
    purchase_id INT PRIMARY KEY IDENTITY,
    customer_id INT,
    product_id INT,
    purchase_date DATE DEFAULT GETDATE()
);
SELECT * FROM  SellerSaleHistory 
CREATE TABLE SellerSaleHistory (
    sale_id INT PRIMARY KEY  IDENTITY,
    seller_id INT,
    product_id INT,
    sale_date DATE DEFAULT GETDATE()
);


CREATE PROCEDURE RecordCustomerPurchase
    @customer_id INT,
    @product_id INT
AS
BEGIN
    -- Insert a new record into CustomerPurchaseHistory
    INSERT INTO CustomerPurchaseHistory (customer_id, product_id)
    VALUES (@customer_id, @product_id);
END;
GO

-- Create the RecordSellerSale stored procedure
CREATE PROCEDURE RecordSellerSale
    @seller_id INT,
    @product_id INT
AS
BEGIN
    -- Insert a new record into SellerSaleHistory
    INSERT INTO SellerSaleHistory (seller_id, product_id)
    VALUES (@seller_id, @product_id);
END;
GO

-- Call the RecordCustomerPurchase stored procedure
DECLARE @customer_id INT
DECLARE @product_id INT
-- Set @customer_id and @product_id to the actual values you want to use
EXEC RecordCustomerPurchase @customer_id, @product_id;

-- Call the RecordSellerSale stored procedure
DECLARE @seller_id INT
-- Set @seller_id and @product_id to the actual values you want to use
EXEC RecordSellerSale @seller_id, @product_id;