CREATE PROCEDURE SP_Department_Name_Employee_Name_MALE
(
    @HireDateFrom DATE,
    @HireDateTo DATE
)
AS 
BEGIN
    SELECT 
        UPPER(d.DEPT_NAME) AS 'Department Name',
        UPPER(d.GROUPNAME) AS 'Group Name',
        UPPER(CONCAT(p.FIRSTNAME, ' ', p.LASTNAME)) AS 'Employee Name',
        UPPER(e.JOBTITLE) AS 'Job Title',
        CONVERT(NVARCHAR(10), e.HIREDATE, 120) AS 'Hire Date',
        DATENAME(MONTH, e.HIREDATE) AS 'Month Hire',
        'W' + RIGHT('00' + CAST(DATEPART(WK, e.HIREDATE) AS NVARCHAR(2)), 2) AS 'Week Hire',
        COALESCE(e.VACATIONHOURS, 0) AS 'Vacation Hours',
        COALESCE(e.SICKLEAVEHOURS, 0) AS 'Sick Leave Hours',
        REPLACE(e.GENDER, 'M', 'Male') AS 'Gender'
    FROM HR_TINOY2.DBO.DEPARTMENT d
    INNER JOIN HR_TINOY2.DBO.PERSON p ON d.DEPARTMENT_ID = p.PERSONID
    LEFT JOIN HR_TINOY2.DBO.EMPLOYEE e ON p.PERSONID = e.PERSONID
    LEFT JOIN HR_TINOY2.DBO.EMPLOYEEDEPARTMENTHISTORY edh ON p.PERSONID = edh.PERSONID
    WHERE e.HIREDATE BETWEEN @HireDateFrom AND @HireDateTo
        AND UPPER(e.GENDER) = 'M'
    ORDER BY 'Department Name', 'Employee Name'
END
SELECT * FROM EMPLOYEE
EXEC SP_Department_Name_Employee_Name_MALE '2009-01-14', '2020-12-31';
------------------------------------------------------------------------------------------
------------------------------------------------------------------------------------------

CREATE PROCEDURE SP_Department_Name_Employee_Name_FEMALE
(
    @HireDateFrom DATE,
    @HireDateTo DATE
)
AS 
BEGIN
    SELECT 
        UPPER(d.DEPT_NAME) AS 'Department Name',
        UPPER(d.GROUPNAME) AS 'Group Name',
        UPPER(CONCAT(p.FIRSTNAME, ' ', p.LASTNAME)) AS 'Employee Name',
        UPPER(e.JOBTITLE) AS 'Job Title',
        CONVERT(NVARCHAR(10), e.HIREDATE, 120) AS 'Hire Date',
        DATENAME(MONTH, e.HIREDATE) AS 'Month Hire',
        'W' + RIGHT('00' + CAST(DATEPART(WK, e.HIREDATE) AS NVARCHAR(2)), 2) AS 'Week Hire',
        COALESCE(e.VACATIONHOURS, 0) AS 'Vacation Hours',
        COALESCE(e.SICKLEAVEHOURS, 0) AS 'Sick Leave Hours',
        REPLACE(e.GENDER, 'F', 'FEMALE') AS 'Gender'
    FROM HR_TINOY2.DBO.DEPARTMENT d
    INNER JOIN HR_TINOY2.DBO.PERSON p ON d.DEPARTMENT_ID = p.PERSONID
    LEFT JOIN HR_TINOY2.DBO.EMPLOYEE e ON p.PERSONID = e.PERSONID
    LEFT JOIN HR_TINOY2.DBO.EMPLOYEEDEPARTMENTHISTORY edh ON p.PERSONID = edh.PERSONID
    WHERE e.HIREDATE BETWEEN @HireDateFrom AND @HireDateTo
        AND UPPER(e.GENDER) = 'F'
    ORDER BY 'Department Name', 'Employee Name'
END
EXEC SP_Department_Name_Employee_Name_FEMALE '2007-01-14', '2020-12-31';
SELECT * FROM EMPLOYEE

------------------------------------------------------------------------------------------
------------------------------------------------------------------------------------------
CREATE PROCEDURE COMBINE(
	@HireDateFrom DATE,
	@HireDateTo DATE
)
AS
BEGIN 		
	 SELECT 
        UPPER(d.DEPT_NAME) AS 'Department Name',
        UPPER(d.GROUPNAME) AS 'Group Name',
        UPPER(CONCAT(p.FIRSTNAME, ' ', p.LASTNAME)) AS 'Employee Name',
        UPPER(e.JOBTITLE) AS 'Job Title',
        CONVERT(NVARCHAR(10), e.HIREDATE, 120) AS 'Hire Date',
        DATENAME(MONTH, e.HIREDATE) AS 'Month Hire',
        'W' + RIGHT('00' + CAST(DATEPART(WK, e.HIREDATE) AS NVARCHAR(2)), 2) AS 'Week Hire',
        COALESCE(e.VACATIONHOURS, 0) AS 'Vacation Hours',
        COALESCE(e.SICKLEAVEHOURS, 0) AS 'Sick Leave Hours',
        REPLACE(e.GENDER, 'M', 'MALE') AS 'Gender'
    FROM HR_TINOY2.DBO.DEPARTMENT d
    INNER JOIN HR_TINOY2.DBO.PERSON p ON d.DEPARTMENT_ID = p.PERSONID
    LEFT JOIN HR_TINOY2.DBO.EMPLOYEE e ON p.PERSONID = e.PERSONID
    LEFT JOIN HR_TINOY2.DBO.EMPLOYEEDEPARTMENTHISTORY edh ON p.PERSONID = edh.PERSONID
    WHERE e.HIREDATE BETWEEN @HireDateFrom AND @HireDateTo
        AND UPPER(e.GENDER) = 'M'
	UNION
	 SELECT 
        UPPER(d.DEPT_NAME) AS 'Department Name',
        UPPER(d.GROUPNAME) AS 'Group Name',
        UPPER(CONCAT(p.FIRSTNAME, ' ', p.LASTNAME)) AS 'Employee Name',
        UPPER(e.JOBTITLE) AS 'Job Title',
        CONVERT(NVARCHAR(10), e.HIREDATE, 120) AS 'Hire Date',
        DATENAME(MONTH, e.HIREDATE) AS 'Month Hire',
        'W' + RIGHT('00' + CAST(DATEPART(WK, e.HIREDATE) AS NVARCHAR(2)), 2) AS 'Week Hire',
        COALESCE(e.VACATIONHOURS, 0) AS 'Vacation Hours',
        COALESCE(e.SICKLEAVEHOURS, 0) AS 'Sick Leave Hours',
        REPLACE(e.GENDER, 'F', 'FEMALE') AS 'Gender'
    FROM HR_TINOY2.DBO.DEPARTMENT d
    INNER JOIN HR_TINOY2.DBO.PERSON p ON d.DEPARTMENT_ID = p.PERSONID
    LEFT JOIN HR_TINOY2.DBO.EMPLOYEE e ON p.PERSONID = e.PERSONID
    LEFT JOIN HR_TINOY2.DBO.EMPLOYEEDEPARTMENTHISTORY edh ON p.PERSONID = edh.PERSONID
    WHERE e.HIREDATE BETWEEN @HireDateFrom AND @HireDateTo
        AND UPPER(e.GENDER) = 'F'
END
EXEC COMBINE '2007-01-14', '2020-12-31'