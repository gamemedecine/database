---
--5 Make a query that shows the product description having the price of greater than 500
--sort by product description in descing order 
---
USE SALES
select PROD_DESCRIPTION,PROD_PRICE  FROM PRODUCT
WHERE PROD_PRICE > 500;

---
--6 Make a query that modify the product on hand  of sketchers to 25
----
USE SALES
UPDATE PRODUCT
SET PROD_ONHAND = 25 
WHERE PROD_DESCRIPTION = 'Sketchers';

---
--7 
----
USE SALES
select PROD_DESCRIPTION,PROD_PRICE  FROM PRODUCT
WHERE PROD_PRICE < 1000
ORDER BY PROD_DESCRIPTION DESC;
