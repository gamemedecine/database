USE SALES_TINOY;
GO
CREATE TABLE SALESTERRITORYREPORT (
    TERRITORY NVARCHAR(50),
    REGION NVARCHAR(50),
    CURRENCYCODE CHAR(3),
    CURRENCY_DESCRIPTION NVARCHAR(50),
    PERIOD_YEAR INT,
    PERIOD_MONTH INT,
    PTD_SALES MONEY,
    YTD_SALES MONEY,
    AVG_YTD_SALES MONEY
);
CREATE PROCEDURE SP_POPULATESALESTERRITORY
    @PERIOD_YEAR INT,
    @PERIOD_MONTH INT
AS
BEGIN
    DECLARE @TERRITORY NVARCHAR(50)
    DECLARE @REGION NVARCHAR(50)
    DECLARE @CURRENCYCODE CHAR(3)
    DECLARE @CURRENCY_DESCRIPTION NVARCHAR(50)
    DECLARE @PTD_SALES MONEY
    DECLARE @YTD_SALES MONEY
    DECLARE @AVG_YTD_SALES MONEY
    DECLARE @Counter INT

    SET @Counter = 1

    WHILE @Counter <= 12
    BEGIN
        SET @YTD_SALES = (
            SELECT SUM(SOH.SUBTOTAL)
            FROM SALESORDERHEADER SOH
            WHERE YEAR(SOH.ORDERDATE) = @PERIOD_YEAR
            AND MONTH(SOH.ORDERDATE) <= @Counter
        );

        SET @AVG_YTD_SALES = @YTD_SALES / @Counter;

        IF EXISTS (
            SELECT 1
            FROM SALESTERRITORYREPORT STR
            WHERE STR.TERRITORY = @TERRITORY
            AND STR.REGION = @REGION
            AND STR.CURRENCYCODE = @CURRENCYCODE
            AND STR.PERIOD_YEAR = @PERIOD_YEAR
            AND STR.PERIOD_MONTH = @Counter
        )
        BEGIN
            DELETE FROM SALESTERRITORYREPORT
            WHERE TERRITORY = @TERRITORY
            AND REGION = @REGION
            AND CURRENCYCODE = @CURRENCYCODE
            AND PERIOD_YEAR = @PERIOD_YEAR
            AND PERIOD_MONTH = @Counter;
        END

        INSERT INTO SALESTERRITORYREPORT (
            TERRITORY, REGION, CURRENCYCODE, CURRENCY_DESCRIPTION, PERIOD_YEAR, PERIOD_MONTH,
            PTD_SALES, YTD_SALES, AVG_YTD_SALES
        )
        VALUES (
            @TERRITORY, @REGION, @CURRENCYCODE, @CURRENCY_DESCRIPTION, @PERIOD_YEAR, @Counter,
            @PTD_SALES, @YTD_SALES, @AVG_YTD_SALES
        );

        SET @Counter = @Counter + 1
    END
END
EXEC SP_POPULATESALESTERRITORY
    @PERIOD_YEAR = 2023, 
    @PERIOD_MONTH = 5;
----------------------------------------------------------------------------------------------------------------------------
----------------------------------------------------------------------------------------------------------------------------
CREATE PROCEDURE SP_POPULATE_TABLE_WITH_DATE_RANGE
    @StartDate DATE,
    @EndDate DATE
AS
BEGIN
   
    CREATE TABLE #TempTable (
        StartDate DATE,
        EndDate DATE
    )

    
    DECLARE @CurrentDate DATE = @StartDate

   
    WHILE @CurrentDate <= @EndDate
    BEGIN
        INSERT INTO #TempTable (StartDate, EndDate)
        VALUES (@CurrentDate, EOMONTH(@CurrentDate))

      
        SET @CurrentDate = DATEADD(MONTH, 1, @CurrentDate)
    END

   
    DECLARE @Start DATE
    DECLARE @End DATE

    DECLARE DateRangeCursor CURSOR FOR
    SELECT StartDate, EndDate
    FROM #TempTable

    OPEN DateRangeCursor

    FETCH NEXT FROM DateRangeCursor INTO @Start, @End

    WHILE @@FETCH_STATUS = 0
    BEGIN
        EXEC SP_POPULATESALESBYTERRITORY @StartDate = @Start, @EndDate = @End

        FETCH NEXT FROM DateRangeCursor INTO @Start, @End
    END

    CLOSE DateRangeCursor
    DEALLOCATE DateRangeCursor

        DROP TABLE #TempTable
END
EXEC SP_POPULATE_TABLE_WITH_DATE_RANGE
    @StartDate = '2011-01-01',
    @EndDate = '2011-07-31';