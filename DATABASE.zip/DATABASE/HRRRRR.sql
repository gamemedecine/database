CREATE PROCEDURE InsertDepartment
(
    @Name VARCHAR(100),
    @GroupName VARCHAR(255)
)
AS
BEGIN
    
    SET @Name = UPPER(@Name)
    SET @GroupName = UPPER(@GroupName)

   
    INSERT INTO DEPARTMENT (Name, GroupName, ModifiedDate)
    VALUES (@Name, @GroupName, GETDATE())
END

CREATE STORED PROCEDURE 