<html>
	<head>
		<title>Add Item</title>
	</head>
	<body>
		<?php
			$id = "";
			$var_description = "";
			$var_qty = "";
			$var_price = "";
			$var_status = "";
			
			$errors = ""; //variable to hold all errors
			
			
			if(isset($_GET["record"]))
			{
				$id = $_GET["record"]; //get the value of the record from the URL parameter
				
				//query the record again, only 1 record
				$db = mysqli_connect("localhost", "root", "", "sales");
				$sql = "select * from item where id = $id";				
				$record = mysqli_query($db, $sql);
				
				//if the record exists, assign all its values to PHP variables...
				if(mysqli_num_rows($record) > 0)
				{
					//get the 1 record only
					$rec = mysqli_fetch_array($record);
					
					//assign to PHP variables
					$var_description = $rec["description"];
					$var_qty = $rec["qty"];
					$var_price = $rec["price"];
					$var_status = $rec["status"];										
				}
				else 
				{
					echo "<p style='color:red;'>Record is no longer existing...</p>";
				}
			}
			
			
			
			if(isset($_POST["BtnSaveChangesItem"]))
			{
				//get all inputs including the ID
				$id = $_POST["TxtID"];
				$var_description = trim($_POST["TxtDescription"]);
				$var_qty = trim($_POST["TxtQty"]);
				$var_price = trim($_POST["TxtPrice"]);
				$var_status = $_POST["CboStatus"];				
			
				
				//error trappings
				if(! is_numeric($var_qty))
				{
					$errors = $errors . "<p style='color:red;'>Quantity must be a number.</p>";
					$var_qty = "";
				}
				
				if(! is_numeric($var_price))
				{
					$errors = $errors . "<p style='color:red;'>Price must be a number.</p>";
					$var_price = "";
				}
					
				if(intval($var_qty) < 0 || intval($var_qty) > 9999)
				{
					$errors = $errors . "<p style='color:red;'>Quantity value must be between 1 and 9,999.</p>";
					$var_qty = "";
				}
					
				if(doubleval($var_price) < 0 || doubleval($var_price) > 999999)	
				{
					$errors = $errors . "<p style='color:red;'>Price value must be between 1.00 and 999,999.00.</p>";
					$var_price = "";
				}
					
				if(is_numeric($var_qty) && intval($var_qty) == 0 && $var_status != "S")
					$errors = $errors . "<p style='color:red;'>Quantity entered is 0. Status must be SOLD-OUT.</p>";
					
				if(is_numeric($var_qty) && intval($var_qty) > 0 && $var_status != "A")
					$errors = $errors . "<p style='color:red;'>Quantity entered is greater than 0. Status must be AVAILABLE.</p>";				
							
				
				
				//check if there are errors, do not proceed if there are errors found
				if($errors != "") //if errors not equal to empty, meaning naay errors nakita
				{
					echo $errors;
				} 
				else 
				{
					//if there are no errors, proceed
					//open a connection
					$db = mysqli_connect("localhost", "root", "", "sales");
					if($db)
					{
						//create the update sql statement
						$sql = " update 
									item
								 set
									description = '".$var_description."', 
									qty = ".$var_qty.", 
									price = ".$var_price.",
									status = '".$var_status."'
								where 
									id = $id ";
								
						//execute the update sql statement
						$query = mysqli_query($db, $sql);
						if($query)
						{
							echo "<p style='color:blue;'><b>Record was updated successfully...</b></p>";
						}
						else 
						{
							echo "<p style='color:red;'>Something went wrong in your query...</p>";
						}
					}
					else 
					{
						echo "<p style='color:red;'>Error connecting to database sales...</p>";
					}
					
					//always close the connection
					mysqli_close($db);					
				}
			}
		?>
		<form method="POST" action="edit.php">
			<table>
				<tr>
					<td>ID:</td>
					<td><input type="text" name="TxtID" readOnly value="<?php echo $id; ?>" /></td>
				</tr>			
				<tr>
					<td>Description:</td>
					<td><input type="text" name="TxtDescription" maxlength="100" required value="<?php echo $var_description; ?>" /></td>
				</tr>
				<tr>
					<td>Quantity:</td>
					<td><input type="text" name="TxtQty" required value="<?php echo $var_qty; ?>" /></td>
				</tr>			
				<tr>
					<td>Price:</td>
					<td><input type="text" name="TxtPrice" required value="<?php echo $var_price; ?>" /></td>
				</tr>				
				<tr>
					<td>Status:</td>
					<td>
						<select name="CboStatus">
							<option value="A"   <?php if($var_status == "A") echo "selected"; ?> >Available</option>
							<option value="S"   <?php if($var_status == "S") echo "selected"; ?> >Sold Out</option>
						</select>
					</td>
				</tr>
				<tr>
					<td></td>
					<td>
						<button type="submit" name="BtnSaveChangesItem">Save Changes Item</button>
						<button type="reset">Reset</button>
						<a href="edit.php">Clear</a>
					</td>
				</tr>					
			</table>
			
		
		</form>
	</body>
</html>