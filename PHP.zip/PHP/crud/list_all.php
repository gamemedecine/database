<html>
	<head>
		<title>List All Items</title>
	</head>
	<body>
		<?php
		
			$db = mysqli_connect("localhost", "root", "", "sales");
			if($db) //if connection is ok
			{
			
				//check if there is a record url parameter variable
				if(isset($_GET["record"]))
				{
					$id = $_GET["record"]; //get the value of the record from the URL parameter
					
					//query the record again, only 1 record, check if the record is still existing...
					//cannot delete a record that is no longer existing...					
					$sql = "select * from item where id = $id";				
					$record = mysqli_query($db, $sql);
					
					//if the record exists, proceed on deleting that record...
					if(mysqli_num_rows($record) > 0)
					{
						//create the delete sql statement
						$sql = "delete from item where id = $id ";
						
						//execute the delete sql statement
						$query = mysqli_query($db, $sql);
						if($query)
						{
							echo "<p style='color:blue;'><b>Record was deleted successfully...</b></p>";
						}
						else 
						{
							echo "<p style='color:red;'>Something went wrong in your query...</p>";
						}						
					}
					else 
					{
						echo "<p style='color:red;'>Record is no longer existing...</p>";
					}
				}				
			
			
			
			
				//query all the record items
				
				//create the select sql statement
				$sql = "select * from item order by description";
				
				//execute the query and all records will be assigned to $records variable from the database
				$records = mysqli_query($db, $sql);
				
				//check if there are records retrieved
				if(mysqli_num_rows($records) > 0) 
				{
					//if naay records
					//display the list in a html table format
					echo "<table border='1'>";
					echo "		<thead>";
					echo "			<tr>";
					echo "				<th>Seq#</th>";
					echo "				<th>ID</th>";
					echo "				<th>Description</th>";
					echo "				<th>Quantity</th>";
					echo "				<th>Price</th>";
					echo "				<th>Status</th>";
					echo "				<th></th>";
					echo "				<th></th>";
					echo "			</tr>";
					echo "		</thead>";
					echo "		<tbody>";
					
					//loop each record here from $records variable
					$sequence = 1;
					while($rec = mysqli_fetch_array($records))
					{
						//use the column names from items table in the array as subscript or index
						echo "<tr>";
						echo "		<td>$sequence.</td>";
						echo "		<td>".$rec["id"]."</td>";
						echo "		<td>".$rec["description"]."</td>";
						echo "		<td align='right'>".$rec["qty"]."</td>";
						echo "		<td align='right'>".$rec["price"]."</td>";
						echo "		<td>".$rec["status"]."</td>";
						echo "		<td><a href='edit.php?record=".$rec["id"]."'>Edit</a></td>";
						echo "		<td><a href='list_all.php?record=".$rec["id"]."' onclick='return confirm(\"Are you sure you want to delete this record?\");'>Delete</a></td>";
						echo "</tr>";
						
						//add 1 to sequence variable after each record
						$sequence = $sequence + 1;
					}
					
					echo "		</tbody>";
					echo "</table>";
					
				}
				else 
				{
					//if no records found, display error message
					echo "<p style='color:red;'>No records found...</p>";
				}
				mysqli_close($db);
			}
			else 
			{
				echo "<p style='color:red;'>Error connecting to database sales...</p>";
			}
		
		
		
		?>
	</body>
</html>