<?php
// Include database connection
require_once('db-connect.php');

// Check if the form is submitted
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Extract form data
    extract($_POST);

    // Sanitize input to prevent SQL injection
    $title = $conn->real_escape_string($title);
    $description = $conn->real_escape_string($description);

    // Additional parameters for the new table
    $task_created = date("Y-m-d H:i:s");
    $task_duedate = $start_datetime; // Assuming start_datetime is the due date
    $task_overdue = ($task_duedate < date("Y-m-d H:i:s")) ? 1 : 0; // Checking if task is overdue

    // Check if it's a new schedule or an update
    if (empty($id)) {
        // Insert new schedule
        $sql_schedule = "INSERT INTO `schedule_list` (`title`,`description`,`start_datetime`,`end_datetime`) VALUES ('$title','$description','$start_datetime','$end_datetime')";

        // Execute the SQL query for schedule
        $save_schedule = $conn->query($sql_schedule);

        // Check if the query was successful
        if (!$save_schedule) {
            echo "<pre>";
            echo "An Error occurred while saving to 'schedule_list' table.<br>";
            echo "Error: " . $conn->error . "<br>";
            echo "SQL: " . $sql_schedule . "<br>";
            echo "</pre>";
            exit; // Exit script if schedule saving fails
        }

        // Inserting into the 'task' table
        $sql_task = "INSERT INTO task (task_title, task_description, task_created, task_duedate, task_overdue) VALUES ('$title', '$description', '$task_created', '$task_duedate', $task_overdue)";

        // Execute the SQL query for the 'task' table
        $save_task = $conn->query($sql_task);

        // Check if the 'task' query was successful
        if ($save_task) {
            echo "<script> alert('Task Successfully Saved.'); location.replace('./') </script>";
        } else {
            echo "<pre>";
            echo "An Error occurred while saving to 'task' table.<br>";
            echo "Error: " . $conn->error . "<br>";
            echo "SQL: " . $sql_task . "<br>";
            echo "</pre>";
        }
    } else {
        // Update existing schedule
        $sql_schedule_update = "UPDATE `schedule_list` SET `title` = '{$title}', `description` = '{$description}', `start_datetime` = '{$start_datetime}', `end_datetime` = '{$end_datetime}' WHERE `id` = '{$id}'";

        // Execute the SQL query for updating schedule
        $update_schedule = $conn->query($sql_schedule_update);

        // Check if the query was successful
        if ($update_schedule) {
            echo "<script> alert('Schedule Successfully Updated.'); location.replace('./') </script>";
        } else {
            echo "<pre>";
            echo "An Error occurred while updating 'schedule_list' table.<br>";
            echo "Error: " . $conn->error . "<br>";
            echo "SQL: " . $sql_schedule_update . "<br>";
            echo "</pre>";
        }
    }
}

// Close the database connection
if (isset($conn)) $conn->close();
?>