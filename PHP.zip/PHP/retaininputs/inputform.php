<html>
	<head>
		<title>Retaining Inputs</title>
	</head>
	<body>
		<?php
			$TxtName = "";
			$CboCivilStatus = "";
			$TxtComment = "";
			
			if(isset($_POST["BtnRetain"]))
			{
				$TxtName = trim($_POST["TxtName"]);
				echo "<p>Hello $TxtName</p>";
				
				//get the selected option's value from CboCivilStatus
				$CboCivilStatus = $_POST["CboCivilStatus"];
				echo "<p>Selected Civil Status: ".$CboCivilStatus."</p>";
				
				//get the inputted comment from the textbox TxtComment
				$TxtComment = trim($_POST["TxtComment"]);
				echo "<p>Comment: $TxtComment</p>";
			}
		?>
		<form method="POST" action="inputform.php">
			<p>Textbox</p>
			<input type="text" name="TxtName" value="<?php echo $TxtName; ?>" />
			<br />
			<br />
			<select name="CboCivilStatus">
				<option value="S"  <?php if($CboCivilStatus == "S") echo "selected"; ?> >Single</option>
				<option value="M"  <?php if($CboCivilStatus == "M") echo "selected"; ?>  >Married</option>
				<option value="D"  <?php if($CboCivilStatus == "D") echo "selected"; ?>  >Divorced</option>
				<option value="W"  <?php if($CboCivilStatus == "W") echo "selected"; ?>  >Widowed</option>			
			</select>
			<br />
			<br />
			<textarea name="TxtComment" placeholder="Type your comment here..." cols="50" rows="5"><?php echo $TxtComment?></textarea>
			
			<input type="submit" name="BtnRetain" value="Retain" />		
		</form>
		<?php echo $TxtName; ?>
	</body>
</html>