<html>
<body>
<h1> Object Oriented Php</h1>
<?php

/*
	//methods
function name(){	
	for($var =1;$var<=6;$var++){
	echo "Number:$var <br>";
	}
}	
name();
	//class----------------------------------------------
	class Fruit{
		public $name;
		public $color;
		
		function Set_name($name){
			$this ->name = $name;
		}
		function Get_name(){
			return $this->name;
		}
	}
	//Object----------------------------------------------
	$apple = new fruit();
	$banana= new fruit();
	$apple ->Set_name("apple");
	$banana ->Set_name("banana");
	echo $apple->Get_name();
	echo "<br>";
	echo $banana->Get_name();
	//Constructort----------------------------------------------
	class Fruit{
		public $name;
		public $color;
		
		function __construct($name,$color){
			
			$this->name=$name;
			$this->color=$color;
		}
		function Get_name(){
			return $this->name;
		}
		function Get_color(){
			return $this->color;
		}
	}
	$strawberry = new Fruit("strawberry","pink");
	echo $strawberry->Get_name();
	echo "<br>";
	echo $strawberry->Get_color();*/
	//Destructort----------------------------------------------
	class Fruit{
		public $name;
		public $color;
		
		function __construct($name,$color){
			
			$this->name=$name;
			$this->color=$color;
		}
		function __destruct(){
			echo "The fruit is {$this->name} and the color is {$this->color}";
		}
	}
	$strawberry = new Fruit("strawberry","pink");
	
	
?>
</body>
</html>