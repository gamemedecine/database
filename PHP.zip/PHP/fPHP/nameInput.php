<!DOCTYPE html>
<html>
<head>
<body>
	<form action ="site.php" method="get">
		Name:<input type="text" name="name">
		<input type="submit">
	</form>
	<br>
<?php
	echo $_GET["name"]
?>	

</body>
</head>
</html>