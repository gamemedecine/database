<html>
<body>
	<h2> My First PHP Webpage </h2>
	
	<?php
		/*
		//variables----------------------------------------------
		$str="Dave Ralph C. Tinoy";
		$num=5;
		$float=7.6;
		
		echo "<h1>".$str."<h1>";
		echo "<h2>".$num."<h2>";
		echo "<h3>".$float."<h3>";
		//array----------------------------------------------
		
		$brand = array("Suzuki","Honda","Rusi");
		echo var_dump($brand[2]);
		//condomain----------------------------------------------
		define("laptop",["Hp", "lenovo and"," Asus"]);
		echo laptop[2];
		//conditions----------------------------------------------
		$var=125;
		if($var %2 == 0 && $var %3 == 0){
			echo "Divisible by both"; 
		}
		elseif($var %2 ==0){
			echo "Divisible by 2";
		}
		elseif($var %3 ==0){
			echo "Divisible by 3";
		}
		else{
			echo "Its not visible by the two numbers";
			
		}
		//Switch----------------------------------------------
		$level =2;
		switch($level){
			case 1:
				echo "You are palying at EASY level";
			break;
			case 2:
				echo "You are palying at MEDIUM level";
			break;
			case 3:
				echo "You are palying at HARD level";
			break;
			case 4:
				echo "You are palying at EXTREME level";
			break;
			default:
				echo "Invalid Input";
		}*/
		
		//Loop----------------------------------------------
		/*$var =2;
		while($var <=10){
			echo "Number:$var <br>";
			$var++;
			
		}
		// do while loop
		$var =11;
		do{
			echo "Number:$var <br>";
			$var++;
			
		}while($var <=10)
		*/
		$var = 10;
		for($var =1;$var<=6;$var++){
			echo "Number:$var <br>";
		}
		
	?>
</body>
</html>