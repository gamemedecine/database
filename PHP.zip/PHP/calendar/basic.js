document.addEventListener('DOMContentLoaded', function () {
  const currentDate = new Date();
  renderCalendar(currentDate);

  document.getElementById('prevMonth').addEventListener('click', function () {
    currentDate.setMonth(currentDate.getMonth() - 1);
    renderCalendar(currentDate);
  });

  document.getElementById('nextMonth').addEventListener('click', function () {
    currentDate.setMonth(currentDate.getMonth() + 1);
    renderCalendar(currentDate);
  });
});

function renderCalendar(date) {
  const currentMonthElement = document.getElementById('currentDate');
  const daysGrid = document.getElementById('daysGrid');
  const options = { month: 'long', year: 'numeric' };
  currentMonthElement.textContent = date.toLocaleDateString('en-US', options);

  // Clear previous content in the daysGrid
  daysGrid.innerHTML = '';

  // Create a header row with day names
  const headerRow = daysGrid.insertRow();
  const daysOfWeek = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];
  for (let day of daysOfWeek) {
    const cell = headerRow.insertCell();
    cell.textContent = day;
  }

  // Get the first day of the month and the total number of days
  const firstDayOfMonth = new Date(date.getFullYear(), date.getMonth(), 1);
  const lastDayOfMonth = new Date(date.getFullYear(), date.getMonth() + 1, 0);

  // Calculate the index of the first day in the current month
  const firstDayIndex = firstDayOfMonth.getDay();

  // Initialize variables
  let currentDay = 1;

  // Loop through each week
  for (let week = 0; week < 6; week++) {
    const row = daysGrid.insertRow();

    // Loop through each day of the week
    for (let dayOfWeek = 0; dayOfWeek < 7; dayOfWeek++) {
      const cell = row.insertCell();

      // Determine if the cell should show a day from the current month or the next month
      if ((week === 0 && dayOfWeek < firstDayIndex) || currentDay > lastDayOfMonth.getDate()) {
        cell.textContent = '';
        cell.classList.add('inactive');
      } else {
        cell.textContent = currentDay;

        // Check if the current cell corresponds to the current day
        if (
          currentDay === new Date().getDate() &&
          date.getMonth() === new Date().getMonth() &&
          date.getFullYear() === new Date().getFullYear()
        ) {
          cell.classList.add('current-day');
        }

        cell.classList.add('active');
        currentDay++;
      }
    }
  }
}
