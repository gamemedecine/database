<html>
	<head>
		<title>Sample POST Action 2</title>
	</head>
	<body>
		<form method="POST" action="action.php">
		
			<p>Enter your name:</p>
			<input type="text" name="TxtName" required /> <br />
			<br />
			<input type="submit" name="BtnSayHi" value="Say Hi" />
			<input type="submit" name="BtnSayHello" value="Say Hello" />
			<input type="submit" name="BtnSayHowAreYou" value="Ask How Are you?" />
			<input type="submit" name="BtnSayNiceToMeetYou" value="Say Nice to Meet You" />		
		</form>
	</body>
</html>