<html>
	<head>
		 <title>Sample Post Action 2</title>
	</head>
	<body>
		<?php
		
			if(isset($_POST["BtnSayHi"]))
			{
				$TxtName = trim($_POST["TxtName"]);
				echo "<p>Hi $TxtName!</p>";
			}
			
			if(isset($_POST["BtnSayHello"]))
			{
				$TxtName = trim($_POST["TxtName"]);
				echo "<p>Hello $TxtName!</p>";
			}
		
			if(isset($_POST["BtnSayHowAreYou"]))
			{
				$TxtName = trim($_POST["TxtName"]);
				echo "<p>How are you $TxtName?</p>";
			}		
			
			if(isset($_POST["BtnSayNiceToMeetYou"]))
			{
				$TxtName = trim($_POST["TxtName"]);
				echo "<p>Nice to meet you $TxtName!</p>";
			}					
		
		?>
		<a href="ui.php">Go Back</a>
	</body>
</html>