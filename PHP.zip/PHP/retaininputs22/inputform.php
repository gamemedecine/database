<html>
	<head>
		<title>Retaining Inputs</title>
	</head>
	<body>
		<?php
			$TxtName = "";
			$CboCivilStatus = "";
			$TxtComment = "";
			$RdGender = "";
			$ChkSubjects = array(); //empty array
			
			
			if(isset($_POST["BtnRetain"]))
			{
				$TxtName = trim($_POST["TxtName"]);
				echo "<p>Hello $TxtName</p>";
				
				//get the selected option's value from CboCivilStatus
				$CboCivilStatus = $_POST["CboCivilStatus"];
				echo "<p>Selected Civil Status: ".$CboCivilStatus."</p>";
				
				//get the inputted comment from the textbox TxtComment
				$TxtComment = trim($_POST["TxtComment"]);
				echo "<p>Comment: $TxtComment</p>";
				
				//get the selected radiobutton's value
				$RdGender = $_POST["RdGender"];
				echo "<p>Gender: $RdGender</p>";
				
				//if user has selected at least 1 subject
				if(isset($_POST["ChkSubjects"]))
				{
					//get all selected / checked subjects from ChkSubjects
					$ChkSubjects = $_POST["ChkSubjects"];
					//loop the selected/checked subjects' values
					for($i=0; $i<count($ChkSubjects); $i++)
					{
						echo "<p>Subject $i ".$ChkSubjects[$i]."</p>";
						
					}										
				}				
				else 
				{
					echo "<p>Please select at least 1 subject.</p>";
					
				}
				
			}
		?>
		<form method="POST" action="inputform.php">
			<p>Textbox</p>
			<input type="text" name="TxtName" value="<?php echo $TxtName; ?>" />
			<br />
			<br />
			<select name="CboCivilStatus">
				<option value="S"  <?php if($CboCivilStatus == "S") echo "selected"; ?> >Single</option>
				<option value="M"  <?php if($CboCivilStatus == "M") echo "selected"; ?>  >Married</option>
				<option value="D"  <?php if($CboCivilStatus == "D") echo "selected"; ?>  >Divorced</option>
				<option value="W"  <?php if($CboCivilStatus == "W") echo "selected"; ?>  >Widowed</option>			
			</select>
			<br />
			<br />
			<textarea name="TxtComment" placeholder="Type your comment here..." cols="50" rows="5"><?php echo $TxtComment?></textarea>
			<br />
			<br />
			<p>Choose gender:</p>
			<input type="radio" name="RdGender" value="M" required <?php if($RdGender == "M") echo "checked"; ?> /> Male <br />
			<input type="radio" name="RdGender" value="F" required <?php if($RdGender == "F") echo "checked"; ?> /> Female <br />			
			<br />
			<br />			
			<p>Choose your favorite subject(s):</p>
			<input type="checkbox" name="ChkSubjects[]" <?php if(in_array("Math", $ChkSubjects)) echo "checked";?>         value="Math" /> Math <br />
			<input type="checkbox" name="ChkSubjects[]" <?php if(in_array("English", $ChkSubjects)) echo "checked";?>      value="English" /> English <br />
			<input type="checkbox" name="ChkSubjects[]" <?php if(in_array("Programming", $ChkSubjects)) echo "checked";?>  value="Programming" /> Programming <br />
			<input type="checkbox" name="ChkSubjects[]" <?php if(in_array("Filipino", $ChkSubjects)) echo "checked";?>     value="Filipino" /> Filipino <br />
			<br />
			<br />
			<input type="submit" name="BtnRetain" value="Retain" />		
		</form>
		<?php echo $TxtName; ?>
	</body>
</html>