<html>
	<head>
		<title>Sample POST Action</title>
	</head>
	<body>
		<?php
			if(isset($_POST["addBtn"]))
			{	
				$TxtNum1 = trim($_POST["TxtNum1"]);
				$TxtNum2 = trim($_POST["TxtNum2"]);
				if(is_numeric($TxtNum1) && is_numeric($TxtNum2))
				{
					echo "Sum of ".$TxtNum1." and ".$TxtNum2
					." is ".$TxtNum1+$TxtNum2."<br />";
				}
				else
				{
					echo "<p style='color:red;'><b>Sorry, num1 and num2 must be numbers. Please try again.</b></p>";										
				}
			}
			/*---------------------------------------------------------------------------------------------*/
			/*---------------------------------------------------------------------------------------------*/
			if(isset($_POST["subtracBtn"]))
			{	
				$TxtNum1 = trim($_POST["TxtNum1"]);
				$TxtNum2 = trim($_POST["TxtNum2"]);
				if(is_numeric($TxtNum1) && is_numeric($TxtNum2))
				{
					echo "Difference of ".$TxtNum1." and ".$TxtNum2
					." is ".$TxtNum1-$TxtNum2."<br />";
				}
				else
				{
					echo "<p style='color:red;'><b>Sorry, num1 and num2 must be numbers. Please try again.</b></p>";										
				}
			}
			/*---------------------------------------------------------------------------------------------*/
			/*---------------------------------------------------------------------------------------------*/
			if(isset($_POST["multiplyBtn"]))
			{	
				$TxtNum1 = trim($_POST["TxtNum1"]);
				$TxtNum2 = trim($_POST["TxtNum2"]);
				if(is_numeric($TxtNum1) && is_numeric($TxtNum2))
				{
					echo "Product of ".$TxtNum1." and ".$TxtNum2
					." is ".$TxtNum1*$TxtNum2."<br />";
				}
				else
				{
					echo "<p style='color:red;'><b>Sorry, num1 and num2 must be numbers. Please try again.</b></p>";										
				}
			}
			/*---------------------------------------------------------------------------------------------*/
			/*---------------------------------------------------------------------------------------------*/
			if(isset($_POST["devideBtn"]))
			{	
				$TxtNum1 = trim($_POST["TxtNum1"]);
				$TxtNum2 = trim($_POST["TxtNum2"]);
				if(is_numeric($TxtNum1) && is_numeric($TxtNum2))
				{
					if($TxtNum2 != 0)
						{
							echo "Quotient of ".$TxtNum1." and ".$TxtNum2." is ".$TxtNum1/$TxtNum2."<br />";
											
						}
						else 
						{
							echo "<p style='color:red;'><b>Sorry, num1 and num2 must be numbers. Please try again.</b></p>";																
						}
				}
				else
				{
					echo "<p style='color:red;'><b>Sorry, num1 and num2 must be numbers. Please try again.</b></p>";										
				}
			}
			/*---------------------------------------------------------------------------------------------*/
			/*---------------------------------------------------------------------------------------------*/
			if(isset($_POST["moduloBtn"]))
			{	
				$TxtNum1 = trim($_POST["TxtNum1"]);
				$TxtNum2 = trim($_POST["TxtNum2"]);
				if(is_numeric($TxtNum1) && is_numeric($TxtNum2))
				{
					if($TxtNum2 != 0)
						{
							echo "Remainder of ".$TxtNum1." and
							".$TxtNum2." is ".$TxtNum1%$TxtNum2."<br />";						
							
						}
						else 
						{
							echo "<p style='color:red;'><b>Sorry, num1 and num2 must be numbers. Please try again.</b></p>";																
						}
				}
				else
				{
					echo "<p style='color:red;'><b>Sorry, num1 and num2 must be numbers. Please try again.</b></p>";										
				}
			}
			
		?>
		<a href="u.php">Go Back</a>
	</body>
</html>