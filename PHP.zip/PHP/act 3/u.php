<html>
	<head>
		<title>Math Operations</title>
	</head>
	<body>
		<form method="POST" action="process.php">
		<span>Enter 1st no.:</span>
		<br />
		<input type="text" name="TxtNum1" required placeholder="Numbers only..." value=""  />
		<br /><br />
		<span>Enter 2nd no.:</span>
		<br />
		<input type="text" name="TxtNum2" required placeholder="Numbers only..." value="" />
		<br />
		<br />
			
			<p>Choose an operation:</p>
			<br /><br />
		
				<input type="submit" name="addBtn" value="+"  />
				<input type="submit" name="subtracBtn" value="-"  />
				<input type="submit" name="multiplyBtn" value="x"  />
				<input type="submit" name="devideBtn" value="/"  />
				<input type="submit" name="moduloBtn" value="%"  />
				<input type="reset" name="resetBtn" value="reset"  />
			</form>
	</body>
</html>