<html>
	<head>
		<title>Math Operations</title>
	</head>
	<body>
		<form method="GET" action="process.php">
			<span>Enter 1st no.:</span>
			<br />
			<input type="text" name="TxtNum1" required placeholder="Numbers only..." value=""  />
			<br /><br />
			<span>Enter 2nd no.:</span>
			<br />
			<input type="text" name="TxtNum2" required placeholder="Numbers only..." value="" />
			<br />
			<br />
			
			<p>Choose your most favorite hero:</p>
			<input type="radio" name="fav_hero" value="add" required /> <label>Addition</label> <br />
			<input type="radio" name="fav_hero" value="sub" required /> <label>Subtract</label> <br />
			<input type="radio" name="fav_hero" value="multiply" required /> <label>Multiplication</label> <br />
			<input type="radio" name="fav_hero" value="devide" required /> <label>Division</label><br />
			<input type="radio" name="fav_hero" value="modulo" required /> <label>Modulo</label>
			<br /><br />
			
			<input type="submit" name="BtnCompute" value="Compute"  />
		</form>
	</body>
</html>