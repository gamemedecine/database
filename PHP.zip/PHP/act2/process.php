<html>
	<head>
		<title>Process Compute</title>
	</head>
	<body>
		<?php
		
			$x = 0;
			$y = 0;
			$sum = 0;
			$difference = 0;
			$product = 0;
			$quotient = 0;
			$remainder = 0;
			$fav_hero="";
			if(isset($_GET["BtnCompute"]))
			{						
					$fav_hero = $_GET["fav_hero"];
				//test if both numbers inputted are numeric
				if(is_numeric($_GET["TxtNum1"]) && is_numeric($_GET["TxtNum2"]))
				{
					
					if($fav_hero == "add")
					{
						echo "Sum of ".$_GET["TxtNum1"]." and ".$_GET["TxtNum2"]." is ".($_GET["TxtNum1"]+$_GET["TxtNum2"])."<br />";	
					}
					if($fav_hero == "sub")
					{
						echo "Difference of ".$_GET["TxtNum1"]." and ".$_GET["TxtNum2"]." is ".($_GET["TxtNum1"]-$_GET["TxtNum2"])."<br />";
					
					}
					if($fav_hero == "multiply")
					{
						echo "Product of ".$_GET["TxtNum1"]." and ".$_GET["TxtNum2"]." is ".($_GET["TxtNum1"]*$_GET["TxtNum2"])."<br />";
					
					}
					if($fav_hero == "devide")
					{
						if($_GET["TxtNum2"] != 0)
						{
							echo "Quotient of ".$_GET["TxtNum1"]." and ".$_GET["TxtNum2"]." is ".($_GET["TxtNum1"]/$_GET["TxtNum2"])."<br />";
											
						}
						else 
						{
							echo "<p style='color:red;'><b>Sorry, num1 and num2 must be numbers. Please try again.</b></p>";																
						}
					}
					if($fav_hero == "modulo")
					{
							if($_GET["TxtNum2"] != 0)
						{
				
							echo "Remainder of ".$_GET["TxtNum1"]." and ".$_GET["TxtNum2"]." is ".($_GET["TxtNum1"]%$_GET["TxtNum2"])."<br />";						
							}
						else 
						{
							echo "<p style='color:red;'><b>Sorry, num1 and num2 must be numbers. Please try again.</b></p>";																
						}
						
					}
					
				}
				else 
				{
					echo "<p style='color:red;'><b>Sorry, num1 and num2 must be numbers. Please try again.</b></p>";										
				}
			}
			else 
			{
				echo "<p style='color:red;'><b>Sorry, invalid action taken.</b></p>";
				
			}
		?>
		
		<a href="act2.php">Go Back</a>
	</body>
</html>