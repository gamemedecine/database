<?php

?>
<html>
	<head>
		<title>Self Submit 1</title>
	</head>
	<body>

		<form method="POST" action="self1.php">
			<p>Enter your name:</p>
			<input type="text" required name="TxtName" />
			<br />
			<input type="submit" name="BtnGreet" value="Greet" />
			<input type="submit" name="BtnGreet" value="SayHello" />
		</form>		
		<form method="POST" action="self1.php">
			<p>This form will determine an inputted number if it is an even or odd number</p>
			<input type="text" name="TxtNumber" required />
			<br />
			<input type="submit" name="BtnDetermine" value="Determine" />
		</form>
		<?php		
			$TxtName = "";
			
			//if the user clicks the BtnGreet button,
			if(isset($_POST["BtnGreet"]))
			{
				//after clicking the BtnGreet, check what value of the button
				//has been clicked
				$TxtName = trim($_POST["TxtName"]);
				if($_POST["BtnGreet"] == "Greet")
				{				
					echo "<p>Good morning $TxtName</p>";				
				}	
				else if($_POST["BtnGreet"] == "SayHello")
				{				
					echo "<p>Hello $TxtName</p>";
				}
			}	

			$TxtNumber = "";
			if(isset($_POST["BtnDetermine"]))
			{
				$TxtNumber = trim($_POST["TxtNumber"]);
				if(! is_numeric($TxtNumber))
				{
					echo "<p>Invalid value entered. Must be numeric. Please try again.</p>";
				}
				else 
				{
					if($TxtNumber % 2 == 0)
					{
						echo "<p>Number is even</p>";
					}
					else 
					{
						echo "<p>Numbe is odd</p>";
					}
				}
			}
		?>		
	</body>
</html>
