<html>
	<head>
		<title>Math Operations</title>
	</head>
	<body>
		<form method="GET" action="process.php">
			<span>Enter 1st no.:</span>
			<br />
			<input type="text" name="TxtNum1" required placeholder="Numbers only..." value=""  />
			<br /><br />
			<span>Enter 2nd no.:</span>
			<br />
			<input type="text" name="TxtNum2" required placeholder="Numbers only..." value="" />
			<br />
			<br />
			<input type="submit" name="BtnCompute" value="Compute"  />
		</form>
	</body>
</html>