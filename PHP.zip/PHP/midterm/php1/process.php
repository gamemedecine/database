<html>
	<head>
		<title>Process Compute</title>
	</head>
	<body>
		<?php
		
			$x = 0;
			$y = 0;
			$sum = 0;
			$difference = 0;
			$product = 0;
			$quotient = 0;
			$remainder = 0;
			
			//this code checks if the user has clicked BtnCompute
			if(isset($_GET["BtnCompute"]))
			{						
				/*
				//get the inputted data from the form.php
				$x = $_GET["TxtNum1"];
				$y = $_GET["TxtNum2"];				
				//if both numbers are numeric
				if(is_numeric($x) && is_numeric($y))
				{
					$sum = $x + $y;
					$difference = $x - $y;
					$product = $x * $y;

					echo "Sum of ".$x." and $y is ".$sum."<br />";
					echo "Difference of $x and $y is $difference<br />";
					echo "Product of $x and $y is $product<br />";
					if($y == 0)
					{
						echo "<p style='color:red;'><b>Sorry, you cannot divide a number by zero.</b></p>";
						
					}
					else 
					{
						$quotient = $x / $y;
						$remainder = $x % $y;
						echo "Quotient of $x and $y is $quotient<br />";
						echo "Remainder of $x and $y is $remainder<br />";
					}					
					
				}
				else 
				{
					echo "<p style='color:red;'><b>Sorry, num1 and num2 must be numbers. Please try again.</b></p>";										
				}
				*/
				
				//test if both numbers inputted are numeric
				if(is_numeric($_GET["TxtNum1"]) && is_numeric($_GET["TxtNum2"]))
				{
					echo "Sum of ".$_GET["TxtNum1"]." and ".$_GET["TxtNum2"]." is ".($_GET["TxtNum1"]+$_GET["TxtNum2"])."<br />";
					echo "Difference of ".$_GET["TxtNum1"]." and ".$_GET["TxtNum2"]." is ".($_GET["TxtNum1"]-$_GET["TxtNum2"])."<br />";
					echo "Product of ".$_GET["TxtNum1"]." and ".$_GET["TxtNum2"]." is ".($_GET["TxtNum1"]*$_GET["TxtNum2"])."<br />";
					if($_GET["TxtNum2"] != 0)
					{
						echo "Quotient of ".$_GET["TxtNum1"]." and ".$_GET["TxtNum2"]." is ".($_GET["TxtNum1"]/$_GET["TxtNum2"])."<br />";
						echo "Remainder of ".$_GET["TxtNum1"]." and ".$_GET["TxtNum2"]." is ".($_GET["TxtNum1"]%$_GET["TxtNum2"])."<br />";						
					}
					else 
					{
						echo "<p style='color:red;'><b>Sorry, num1 and num2 must be numbers. Please try again.</b></p>";																
					}					
				}
				else 
				{
					echo "<p style='color:red;'><b>Sorry, num1 and num2 must be numbers. Please try again.</b></p>";										
				}
			}
			else 
			{
				echo "<p style='color:red;'><b>Sorry, invalid action taken.</b></p>";
				
			}
		?>
		
		<a href="form.php">Go Back</a>
	</body>
</html>