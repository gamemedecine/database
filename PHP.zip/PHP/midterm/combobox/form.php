<html>
	<head>
		<title>Combobox</title>
	</head>
	<body>
		<form method="GET" action="process.php">
			Select gender:
			<br />
			<select name="Gender">
				<!-- These are the options -->
				<option value="S" >Straight</option>
				<option value="L" >LGBTQ+</option>
				<option value="N" >Non-Binary</option>
			</select>
			<br />
			<input type="submit" name="BtnDetermine" value="Determine" />
		</form>
	</body>
</html>