<html>
	<head>
		<title>Check Gender</title>
	</head>
	<body>
		<?php
		
			$Gender = "";
			
			if(isset($_GET["BtnDetermine"]))
			{				
				//get the value of the SELECTED option from combobox Gender
				$Gender = $_GET["Gender"];
				echo "Gender Value: $Gender<br />";
				
			}		
		?>
		<a href="form.php">Go Back</a>
	</body>
</html>