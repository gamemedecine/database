<html>
	<head>
		<title></title>
	</head>
	<body>
	<?php
	
		//get the data/value from the textbox txtname
		$txtname = $_GET["txtname"];
		
		//then display it
		echo "Hello $txtname";
	
	
	?>
	
	
	</body>
</html>