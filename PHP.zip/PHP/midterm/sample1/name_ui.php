<html>
	<head>
		<title>Enter name</title>
	</head>
	<body>
		<form method="GET" action="name_process.php">
			<p>Enter your name:</p>
			<input type="text" name="txtname" maxlength="20" />
			<br />
			<input type="submit" name="btnsubmit" value="Get Name" />
		</form>
	</body>
</html>