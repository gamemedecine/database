<html>
	<head>
		<title>Basic Forms</title>
	</head>
	<body>
		<form method="GET" action="">
			<input maxlength="100" type="text" size="50" placeholder="Type something..." value="Joaquin"   />
			
			<!-- 3 kinds of buttons -->
			<!-- 1. submit button -->
			<input type="submit" value="Save Changes" />
		
		</form>
	</body>
</html>