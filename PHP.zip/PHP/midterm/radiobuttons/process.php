<html>
	<head>
		<title>Process Radiobuttons</title>
	</head>
	<body>
		<?php
	
			//check if the user clicks the BtnSelect button
			if(isset($_GET["BtnSelect"]))
			{
				$fav_subject = $_GET["fav_subject"];
				$fav_hero = $_GET["fav_hero"];
				
				echo "<p>Your favorite subject: $fav_subject</p>";
				echo "<p>Your favorite hero: $fav_hero</p>";
			}
			else 
			{
				echo "<p style='color:red;'><b>Sorry, invalid action taken.</b></p>";
			}
			
			echo "<a href='form.php'>Go Back</a>";
			
		
		
		
		
		?>
	</body>
</html>