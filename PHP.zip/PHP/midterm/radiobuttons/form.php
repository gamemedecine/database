<html>
	<head>
		<title>Radiobuttons</title>
	</head>
	<body>
		<form method="GET" action="process.php">
			<p>Choose your most favorite subject:</p>
			<input type="radio" name="fav_subject" value="Math and Science" required /> <label>Mathematics and Science Technology</label> <br />
			<input type="radio" name="fav_subject" value="English" required /> <label>English and Literature</label> <br />
			<input type="radio" name="fav_subject" value="Programming" required /> <label>Computer Programming</label> <br />
			<input type="radio" name="fav_subject" value="Socio" required /> <label>Society and Culture</label> <br />
			<br /><br />
			
			<p>Choose your most favorite hero:</p>
			<input type="radio" name="fav_hero" value="Superman" required /> <label>Superman</label> <br />
			<input type="radio" name="fav_hero" value="Darna" required /> <label>Darna</label> <br />
			<input type="radio" name="fav_hero" value="Batman" required /> <label>Batman</label> <br />
			<input type="radio" name="fav_hero" value="Jake" required /> <label>Jake</label>
			<br /><br />
			
			<input type="submit" name="BtnSelect" value="Select" />
		
		
		
		
		</form>
	</body>
</html>