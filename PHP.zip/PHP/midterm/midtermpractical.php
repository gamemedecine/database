<!DOCTYPE html>
<html>
	<head>
	<?php
		$Quantity="";
		$Price="";
		$Total="";
		$Select_Discount="";
		$DiscountAmount="";
		
		if(isset($_POST["BtnRetain"]))
			{
				$Quantity = trim($_POST["Quantity"]);
				$Price= trim($_POST["Price"]);
				$Select_Discount = $_POST["Select_Discount"];
				if(is_numeric($Quantity) && is_numeric($Price))
				{
						if($Quantity > 1.0 && $Quantity <=100.00)
						{
							
							if($Price >1.0 && $Price <= 1000.00)
							{
						
								if($Select_Discount == "Regular")
								{
									
									echo "<p>Hello Regular.</p>";
									$Total = $Quantity*$Price;
									$DiscountAmount=0.00;
								}
								if($Select_Discount=="Senior")
								{
									$DiscountAmount = $Price * 0.20;
									$Total = $DiscountAmount - $Price;
								}
							}
						}
					}
				}
				else{
					echo "<p>Please Enter A Number.</p>";
					
				}
				
				
			
			
	?>
	<form method="POST" action="midtermpractical.php">
	<p>Textbox</p>
	<div style="position: absolute; top: 45px; left: 400px" >
		<input type="text" name="Quantity" value="<?php echo $Quantity; ?>" />
		<br/>
		<br/>
		<input type="text" name="Price" value="<?php echo $Price; ?>" />
	</div>
	<p>Enter No. of Qty Purchased:</p>
	<p>Enter Item Price:</p>
	<br />
	<br />
	<p>Select Discount:</p>
	<input type="radio" name="Select_Discount" value="Regular" required /> <label>Regualar, No Discount</label>
	<br/>
	<br/>
	<input type="radio" name="Select_Discount" value="Senior" required /><label>Senior Discount</label><br/>
	<br/>
	<br/>
	<input type="submit" name="BtnRetain" value="Retain" style="border-radius: 8px; height: 50px; width: 11%;" />	
	 <p>Total Ammount:<?php echo $Total; ?></p>
	 <p>Discounted Total Ammount: <?php echo $DiscountAmount; ?></p>
	</head>
</html>