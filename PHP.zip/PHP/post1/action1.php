<html>
	<head>
		<title>Sample POST Action</title>
	</head>
	<body>
		<?php
			if(isset($_POST["BtnSubmit"]))
			{
				$TxtName = trim($_POST["TxtName"]);
				echo "<p>Hello $TxtName! From action1.php</p>";			
			}
				
		?>
		<a href="ui.php">Go Back</a>
	</body>
</html>