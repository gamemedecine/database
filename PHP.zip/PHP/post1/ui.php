<html>
	<head>
		<title>Post Sample 1</title>
	</head>
	<body>
		<form method="POST" action="action1.php">			
			<p>Enter your name:</p>
			<input type="text" name="TxtName" required /> <br />
			<input type="submit" name="BtnSubmit" value="Submit POST" />				
		</form>
		
		<form method="POST" action="action2.php">
			<p>Enter your name:</p>
			<input type="text" name="TxtName" required /> <br />
			<input type="submit" name="BtnSubmit" value="Submit POST" />										
		</form>
		
	</body>
</html>