<!DOCTYPE html>
<html>
	<head>
		<title>Retaining Inputs</title>
	</head>
	<body>
		<?php
			$Txtnum1 = "";
			$Txtnum2 = "";
			$ChkOps = array();
			$Operations = array(); // Use an array to store selected operations

			if (isset($_POST["BtnRetain"])) {
				$Txtnum1 = trim($_POST["Txtnum1"]);
				$Txtnum2= trim($_POST["Txtnum2"]);

				

				if (isset($_POST["ChkOps"])) {
					// Get all selected/checked subjects from ChkSubjects
					$ChkOps = $_POST["ChkOps"];

					// Loop the selected/checked subjects' values using a for loop
					for ($i = 0; $i < count($ChkOps); $i++) {
						$selectedOperation = $ChkOps[$i];
						echo "<p>Operation: $selectedOperation</p>";
						$Operations[] = $selectedOperation; // Store selected operations in an array
					}
				} else {
					echo "<p>Please select at least 1 subject.</p>";
				}
			}
		?>
		<form method="POST" action="act4.php">
			<p>Textbox</p>
			<input type="text" name="Txtnum1" value="<?php echo $Txtnum1; ?>" />
			<br />
			<br />
			<input type="text" name="Txtnum2" value="<?php echo $Txtnum2; ?>" />
			<br />
			<br />
			<p>Choose Operation(s):</p>
			<input type="checkbox" name="ChkOps[]" <?php if(in_array("Addition", $ChkOps)) echo "checked";?> value="Addition" /> Addition<br />
			<input type="checkbox" name="ChkOps[]" <?php if(in_array("Subtraction", $ChkOps)) echo "checked";?> value="Subtraction" /> Subtraction<br />
			<input type="checkbox" name="ChkOps[]" <?php if(in_array("Multiplication", $ChkOps)) echo "checked";?> value="Multiplication" /> Multiplication<br />
			<input type="checkbox" name="ChkOps[]" <?php if(in_array("Division", $ChkOps)) echo "checked";?> value="Division" /> Division<br />
			<input type="checkbox" name="ChkOps[]" <?php if(in_array("Modulo", $ChkOps)) echo "checked";?> value="Modulo" /> Modulo<br />
			<br />

			<input type="submit" name="BtnRetain" value="Retain" />
		</form>
		<div style="position: absolute; top: 40px; right: 70px; padding: 10px; border-radius: 5px;">
			<?php
				// Use a for loop to handle the selected operations
				for ($j = 0; $j < count($Operations); $j++)
					{
						$selectedOperation = $Operations[$j];

						// Use if statements to display results for selected operations
						if ($selectedOperation == "Addition") {
							if (is_numeric($Txtnum1) && is_numeric($Txtnum2)) {
								echo "Sum of $Txtnum1 and $Txtnum2 is " . ($Txtnum1 + $Txtnum2) . "<br />";
							} else {
								echo "<p style='color:red;'><b>Sorry, num1 and num2 must be numbers. Please try again.</b></p>";
							}
					}

						if ($selectedOperation == "Subtraction") {
							if (is_numeric($Txtnum1) && is_numeric($Txtnum2)) {
								echo "Difference of $Txtnum1 and $Txtnum2 is " . ($Txtnum1 - $Txtnum2) . "<br />";
							} else {
								echo "<p style='color:red;'><b>Sorry, num1 and num2 must be numbers. Please try again.</b></p>";
							}
						}
						/*---------------------------------------------------------------------------------------------*/
						/*---------------------------------------------------------------------------------------------*/
						if($selectedOperation == "Multiplication") 
						{	
							$Txtnum1 = trim($_POST["Txtnum1"]);
							$Txtnum2 = trim($_POST["Txtnum2"]);
							if(is_numeric($Txtnum1) && is_numeric($Txtnum2))
							{
								echo "Product of ".$Txtnum1." and ".$Txtnum2
								." is ".$Txtnum1*$Txtnum2."<br />";
							}
							else
							{
								echo "<p style='color:red;'><b>Sorry, num1 and num2 must be numbers. Please try again.</b></p>";										
							}
						}
						/*---------------------------------------------------------------------------------------------*/
						/*---------------------------------------------------------------------------------------------*/
						if($selectedOperation == "Division") 
						{	
							$Txtnum1 = trim($_POST["Txtnum1"]);
							$Txtnum2 = trim($_POST["Txtnum2"]);
							if(is_numeric($Txtnum1) && is_numeric($Txtnum2))
							{
								if($Txtnum2 != 0)
									{
										echo "Quotient of ".$Txtnum1." and ".$Txtnum2." is ".$Txtnum1/$Txtnum2."<br />";
														
									}
									else 
									{
										echo "<p style='color:red;'><b>Sorry, num1 and num2 must be numbers. Please try again.</b></p>";																
									}
							}
							else
							{
								echo "<p style='color:red;'><b>Sorry, num1 and num2 must be numbers. Please try again.</b></p>";										
							}
						}
						/*---------------------------------------------------------------------------------------------*/
						/*---------------------------------------------------------------------------------------------*/
						if($selectedOperation == "Modulo") 
						{	
							$TxtNum1 = trim($_POST["Txtnum1"]);
							$Txtnum2 = trim($_POST["Txtnum2"]);
							if(is_numeric($Txtnum1) && is_numeric($Txtnum2))
							{
								if($Txtnum2 != 0)
									{
										echo "Remainder of ".$Txtnum1." and
										".$Txtnum2." is ".$Txtnum1%$Txtnum2."<br />";						
										
									}
									else 
									{
										echo "<p style='color:red;'><b>Sorry, num1 and num2 must be numbers. Please try again.</b></p>";																
									}
							}
							else
							{
								echo "<p style='color:red;'><b>Sorry, num1 and num2 must be numbers. Please try again.</b></p>";										
							}
						}

					
				}
			?>
		</div>
	</body>
</html>