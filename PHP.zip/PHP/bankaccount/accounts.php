<html>
	<head>
		<title>Accounts</title>
	</head>
	<body>
		<?php
			$ChkSubjects = array();
			
			$var_db = mysqli_connect("localhost", "root", "", "bank");
			if($var_db){
				//query all the record items
				//create the select sql statement
				$var_sql = "select * from account order by id";
				
				//execute the query and all records will be assigned to $records variable from the database
				$var_records = mysqli_query($var_db, $var_sql);
				if(mysqli_num_rows($var_records) > 0) 
				{
					//if naay records
					//display the list in an HTML table format
					echo "<form method='get' action=''>";
					echo "<table border='1'>";
					echo "		<thead>";
					echo "			<tr>";
					echo "				<th>Seq#</th>";
					echo "				<th>id</th>";
					echo "				<th>Account No</th>";
					echo "				<th>Account Name</th>";
					echo "				<th>Balance</th>";
					echo "				<th>Status</th>";
					echo "				<th></th>";
					echo "			</tr>";
					echo "		</thead>";
					echo "		<tbody>";
					
					$sequence = 1;
					while($rec = mysqli_fetch_array($var_records))
					{
						//use the column names from items table in the array as subscript or index
						echo "<tr>";
						echo "		<td>$sequence.</td>";
						echo "		<td>".$rec["id"]."</td>";
						echo "		<td>".$rec["account_no"]."</td>";
						echo "		<td align='right'>".$rec["account_name"]."</td>";
						echo "		<td align='right'>".$rec["balance"]."</td>";
						echo "		<td>".$rec["status"]."</td>";
						echo "		<td><a href='edit.php?record=".$rec["id"]."'>Edit</a></td>";
						echo "		<td><input type='checkbox' name='ChkSubjects[]'" . (in_array($rec["id"], $ChkSubjects) ? ' checked' : '') . " value=" . $rec["id"] . " /></td>";
						echo "</tr>";
						
						//add 1 to sequence variable after each record
						$sequence = $sequence + 1;
					}
					
					echo "		</tbody>";
					echo "</table>";
					echo "<input type='submit' name='BtnDelete' value='Delete' />";
					echo "</form>";
				
				}

				if (isset($_GET["BtnDelete"])) {
					$ChkSubjects = $_GET["ChkSubjects"];

					// Check if at least one checkbox is selected
					if (count($ChkSubjects) > 0) {
						// loop through the selected/checked subjects' values
						for ($i = 0; $i < count($ChkSubjects); $i++) {
							// create the delete sql statement for each selected item
							$var_sql = "DELETE FROM account WHERE id = " . $ChkSubjects[$i];

							// execute the delete statement for each selected item
							$var_records = mysqli_query($var_db, $var_sql);

							// Check if the delete query was successful
							if (!$var_records) {
								// Add error handling or logging here if needed
								echo "<p style='color:red;'>Error deleting record with ID: " . $ChkSubjects[$i] . "</p>";
							}
						}
					} else {
						echo "<p style='color:red;'>Please select at least one account to delete.</p>";
					}
				}	
				
				mysqli_close($var_db);
			
			}	

			else 
			{
				echo "<p style='color:red;'>Error connecting to the database...</p>";
			}
		?>
		<a href="create.php">Back</a>
	</body>
</html>