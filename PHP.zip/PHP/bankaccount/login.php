<html>
	<head>
		<title>Bank Account</title>
		<link rel="stylesheet" href="bankstyle.css">
	</head>
	<body>
		<div class="logincard">
			<h1 style="text-align:center; ">Login</h1>
			<br>
			<br>
			<p style="position: absolute; left: 80px; font-size: 20px">Username:</p> 
			<br>
			<br>
			<br>
			<input class="box" type="text" name="TxtUsername" style="position: absolute; left: 80px; height: 30px;width:400px;" required />
			<br>
			<br>
			<br>
			<p style="position: absolute; left: 80px; font-size: 20px">Password:</p> 
			<br>
			<br>
			<br>
			<input class="box" type="text" name="TxtUsername" style="position: absolute; left: 80px; height: 30px;width:400px;"required />
			<br>
			<br>
			<br>
			<br>
			<input type="submit" name="BtnLogin" value="Login" style="background-color:#AEB8BF;position: absolute; left: 210px; font-size: 20px; height: 30px;width:120px;">
			<br>
			<p style="position: absolute; left: 210px; font-size: 20px">Create account</p>
			
		</div>
		
		
	</body>
</html>