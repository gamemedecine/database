<html>
	<head>
		<title>Edit</title>
	</head>
	<body>
		<?php
		$var_id ="";
		$var_AccNum ="";
		$var_AccName ="";
		$var_AccBalance="";
		$var_Status="";
		$var_error="";
		$var_prompt = "";
		
		$errors = ""; // variable to hold all errors
		
		if(isset($_GET["record"]))
		{
			$var_id = $_GET["record"]; // get the value of the record from the URL parameter
			
			// query the record again, only 1 record
			$db = mysqli_connect("localhost", "root", "", "bank");
			$sql = "select * from account where id = $var_id";				
			$record = mysqli_query($db, $sql);
			
			// if the record exists, assign all its values to PHP variables...
			if(mysqli_num_rows($record) > 0)
			{
				// get the 1 record only
				$rec = mysqli_fetch_array($record);
				
				// assign to PHP variables
				$var_AccNum = $rec["account_no"];
				$var_AccName = $rec["account_name"];
				$var_AccBalance = $rec["balance"];
				$var_Status = $rec["status"]; // assign status value
			}
			else 
			{
				echo "<p style='color:red;'>Record is no longer existing...</p>";
			}
		}
		
		if(isset($_POST["BtnSaveChangesItem"]))
		{
			// get all inputs including the ID
			$var_id = $_POST["TxtID"];
			$var_AccNum = $_POST["TxtAccNo"];
			$var_AccName = trim($_POST["TxtAccName"]); // fix the input name
			$var_AccBalance = trim($_POST["TxtAccBalance"]); // fix the input name
			$var_Status = $_POST["RadStatus"];
			
			// error trappings
			if(is_numeric($var_AccName)){
				$var_error = $var_error."<p style='color=red'>Account Name should be letters</p>";
			}
			if(!is_numeric($var_AccBalance) || intval($var_AccBalance) < 0 || $var_AccBalance > 999999999){
				$var_error = $var_error."<p style='color=red'>Balance should be a number or would not exceed to 999999999 limit. </p>";
			}
			if($var_Status == "Dormant" && $var_AccBalance != 0){
				$var_error = $var_error."<p style='color=red'>The Status is Dormant. The Balance Should be 0</p>";
			}
			if($var_Status == "Active" && $var_AccBalance == 0){
				$var_error = $var_error."<p style='color=red'>The Status is Active. The Balance Should be greater than 0</p>";
			}
			
			if($var_error != "") // if errors not equal to empty, meaning naay errors nakita
			{
				echo "<div  style='background-color: white; width: 13%; height: 180px; position:relative; left:10%;'>";
				echo "<p>'$var_error'</p>";
				echo "</div>";
			} 
			else
			{
				// connect to database
				$var_db = mysqli_connect("localhost", "root", "", "bank");
				if($var_db){
					$sql = "update 
							account
							set
								account_name = '".$var_AccName."',
								balance = '".$var_AccBalance."',
								status = '".$var_Status."'
							where 
							id = $var_id ";
					$var_query = mysqli_query($var_db, $sql);
					if($var_query)
					{
						echo "<p style='color:blue;'><b>Record was updated successfully...</b></p>";
					}
					else 
					{
						echo "<p style='color:red;'>Something went wrong in your query...</p>";
					}
				}
				else{
					echo "<p style='color:red;'>Error connecting to database sales...</p>";
				}
				mysqli_close($var_db);
			}
		}		
		?>
		<form method="POST" action="edit.php">
			<table>
				<tr>
					<td>ID:</td>
					<td><input type="text" name="TxtID" readonly value="<?php echo $var_id; ?>" /></td>
				</tr>	
					<tr>
					<td>Account Number:</td>
					<td><input type="text" name="TxtAccNo" readonly value="<?php echo $var_AccNum; ?>" /></td>
				</tr>
				<tr>
				
					<td>Account Name:</td>
					<td><input type="text" name="TxtAccName" value="<?php echo $var_AccName ?>" maxlength="50" required/></td>
				</tr>
				<tr>
					<td>Balance:</td>
					<td><input type="text" name="TxtAccBalance" value="<?php echo $var_AccBalance ?>" required/></td>
				</tr>
				<tr>
					<td>Status:</td>
					<td>
					
						<input  name="RadStatus" type="radio"  value="A" <?php if($var_Status =="A") echo "checked";?> required /><label style="font-size: 20px">Active</label>
						<input name="RadStatus" type="radio"  value="D"<?php if($var_Status =="D")  echo "checked"; ?>  required /><label style="font-size: 20px">Dormant</label></div>
				</td>
							</tr>
				<tr>
					<td></td>
					<td>
						<button type="submit" name="BtnSaveChangesItem">Save Changes Item</button>
						<button type="reset">Reset</button>
						<a href="edit.php">Clear</a>
						<a href="accounts.php">Back</a>
					</td>
				</tr>					
			</table>
		</form>
	</body>
</html>