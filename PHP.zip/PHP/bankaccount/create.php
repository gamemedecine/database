<html>
	<head>
		<title>Create Account</title>
		<link rel="stylesheet" href="bankstyle.css" >
	</head>
	<body>
		<?php
			$var_AccNum ="";
			$var_AccName ="";
			$var_AccBalance="";
			$var_Status="";
			$var_error="";
			$var_prompt = "";

			if(isset($_POST["BtnSubmit"]))
			{
				$var_AccNum = trim($_POST["TxtAccNo"]);
				$var_year = intval(substr($var_AccNum, 0, 4)); 
				$middlePart = substr($var_AccNum, 4, 2); 
				$var_AccName= trim($_POST["TxtAccName"]);
				$var_AccBalance= trim($_POST["TxtAccBalance"]);
				$var_Status = $_POST["RadStatus"];
						
				if (is_numeric($var_year) && $var_year < 1900 || $var_year > date("Y")) {
					$var_error = $var_error ."<p style='color=red'>Follow The Format 'YYYY'</p>";
					
				}
				if ($middlePart !== "08") {
						$var_error = $var_error ."<p style='color=red'>Follow The Format '08'</p>";
					}
				if(! is_numeric($var_AccNum)){
					$var_error = $var_error ."<p style='color=red'>Account Number should be a nmmber</p>";
				}
				if(is_numeric($var_AccName)){
					$var_error=$var_error."<p style='color=red'>Account Name should be letters</p>";
				}
				if(! is_numeric($var_AccBalance) || intval($var_AccBalance) < 0 || $var_AccBalance > 999999999){
					$var_error=$var_error."<p style='color=red'>Balance should be a number or would not exced to 999999999 limit. </p>";
					
				}
				if($var_Status == "Dormant" && $var_AccBalance != 0){
					
					$var_error=$var_error."<p style='color=red'>The Status is dormant The Balance Should be 0</p>";
				}
				if($var_Status == "Active" && $var_AccBalance == 0){
					
					$var_error=$var_error."<p style='color=red'>The Status is dormant The Balance Should be greater 0</p>";
				}
				if($var_error != "") //if errors not equal to empty, meaning naay errors nakita
				{
				
					echo "<div  style='background-color: white; width: 13%; height: 180px; position:relative; left:10%;'>";
					echo "<p>'$var_error'</p>";
					echo "</div>";
				} 
					
				else{
				
					//connect to database
					$var_db = mysqli_connect("localhost", "root", "" ,"bank");
					if($var_db){
						$var_check = "select * from account where account_no = '$var_AccNum'";
						$var_result =mysqli_query ($var_db,$var_check);
						
						if(mysqli_num_rows($var_result) >0){
							$var_prompt = "Account number already Exist...";
						}
						else{
							$var_sql = "insert into account (account_no, account_name, balance, status) values 
								('$var_AccNum', '$var_AccName', $var_AccBalance, '$var_Status') ";
		
							//execute sql query
							$var_query = mysqli_query($var_db, $var_sql);
							if($var_query){
								echo "<p style='color: green'>Data succesfully saved..</p>";
									$var_AccNum = "";
									$var_AccName="";
									$var_AccBalance="";
									$var_Status="";
							}
							else{
								
								echo "<p style='color: red'>Data was not saved. Check query</p>";
							}
						}
							
					}
					else{
						
						echo "<p style='color:red;'>Error connecting to database sales...</p>";
					}
				mysqli_close($var_db);
				
				}
	
			}
					
		?>
		<form method="POST" action="create.php">
		<div class="account">
			<h1 style="text-align:center; ">Create Account</h1>
			<p style="text-align:center;" ><?php echo $var_prompt;?></p>
			
			<br>
			<br>
			<p style="position: absolute; left: 224px; font-size: 15px">Format:YYYY08NNNN:</p> <br>
			<p style="position: absolute; left: 80px; font-size: 20px">Account No:</p> <br>
			<input class="box" type="text" name="TxtAccNo" value="<?php echo $var_AccNum?>" maxlength="10" style="position: absolute; right: 80px; height: 30px;width:300px;" required/>
			<br>
			<br>
			
			<p style="position: absolute; left: 80px; font-size: 20px">Account Name:</p> <br>
			<input class="box" type="text" name="TxtAccName" value="<?php echo $var_AccName?>" maxlength="50" style="position: absolute; right: 80px; height: 30px;width:300px;" required/>
			<br>
			<br>
			<p style="position: absolute; left: 80px; font-size: 20px">Balance:</p> <br>
			<input class="box" type="text" name="TxtAccBalance" value="<?php echo $var_AccBalance?>"  style="position: absolute; right: 80px; height: 30px;width:300px;" required/>
			<br>
			<br>
			<p style="position: absolute; left: 80px; font-size: 20px">Status:</p> <br>
				
			<div style="position: absolute; right: 220px;">
				<input   type="radio" name="RadStatus"  value="A" <?php if($var_Status =="A") echo "checked";?> required /><label style="font-size: 20px">Active</label>
				<input  type="radio" name="RadStatus"  value="D"<?php if($var_Status =="D")  echo "checked"; ?>  required /><label style="font-size: 20px">Dormant</label>
			</div><br>
			<br>
			<br>
			<button type="submit" name="BtnSubmit" style="position: absolute; left: 130px; font-size: 20px"> SAVE</button>
			<button type="reset"  style="position: absolute; right: 130px; font-size: 20px">Reset</button>
			<br>
			<br>
			<a href="create.php" style="position: absolute; right: 288px; font-size: 20px">Clear</a><br><br>
			<a href="accounts.php" style="position: absolute; right: 260px; font-size: 20px">list of account</a>
		
			
		</div>
		</form>	
	</body>
</html>