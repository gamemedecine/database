from sys import path

path.insert(0,"../util/")

from dbhelper import *

table:str = "users"

def login(**kwargs)->dict:
    keys:list =list(kwargs.keys())
    values:list=list (kwargs.values())
    sql:str = f"SELECT * FROM `users` WHERE `{keys[0]}`='{values[0]}' AND `{keys[1]}`='{values[1]}' "
    cursor:object =db.cursor()
    cursor.execute(sql)
    user:dict =cursor.fetchone()
    cursor.close()
    return user
def getalluser()->list:             return getall(table)
def updateuser(**kwargs)->bool:     return updaterecord(table,**kwargs)
def deleteuser(**kwargs)->bool:     return deleterecord(table,**kwargs)    


def main()->None:
    ok:dict = login(username="admin",password="user")
    print(ok)
    
if __name__=="__main__":
    main() 
