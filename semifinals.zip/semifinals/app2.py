from flask import Flask,render_template,request,flash,session,redirect
from sys import path
path.insert(0,"util/")
path.insert(0,"service/")

from dbhelper import *
from service.userservice import *


app=Flask(__name__)
app.secret_key="&^@#!@SSaaaa!"

@app.route("/deletestudent", methods=["GET"])
def deletestudent():
    idno:str = request.args.get("idno")
    ok:bool= deleterecord('student',idno=idno)
    if ok:
        flash("Student with IDNO: " + idno + " is Deleted")
        return redirect("/main")
    
@app.route("/main")
def main():
    if "logged" in session:
        tableheader:list=['idno','lastname','firstname','course','level','action']
        students:list = getallrecord('student')
        return render_template("main.html",rows=students,header=tableheader,topheader="STUDENT LIST")
    else:
        flash("Log in Properly")
        return redirect("/")

@app.route("/validateuser",methods=['POST'])
def validateuser():
    uname:str =request.form["username"]
    pword:str =request.form["password"]
    user: dict = login(username=uname,password=pword)
    if user!=None:
        session["logged"] = uname
        flash("Login Successfull")
        return redirect("/main")
    else:
        flash("Login Failed")
        return redirect("/")
@app.route("/logout")
def logout():
    session.clear()
    flash("you are logged out")
    return redirect("/")
    
    
@app.after_request
def after_request(response):
    response.headers["Cache-Control"]="no-cache,no-store,must-revalidate"
    return response
@app.route("/savestudent",methods=["POST"])
def savestudent():
    try:
        idno = request.form["idno"]
        lastname = request.form["lastname"]
        firstname = request.form["firstname"]
        course = request.form["course"]
        level = request.form["level"]
        flag = request.form["flag"]

        if idno and lastname and firstname:
            if flag == "0":
                okey = addrecord('student', idno=idno, lastname=lastname, firstname=firstname, course=course, level=level)
                if okey:
                    flash("New student added")
                else:
                    raise Exception("Failed to add student")
            else:
                okey = updaterecord('student', idno=idno, lastname=lastname, firstname=firstname, course=course, level=level)
                if okey:
                    flash("Student updated")
                else:
                    raise Exception("Failed to update student")
        else:
            raise Exception("Invalid input data")

        return redirect("/main")

    except Exception as e:
        flash(f"Error: {str(e)}")
        return redirect("/main")
     
@app.route("/")
def index():
    return render_template("login.html",topheader="USERLOGIN")

if __name__=="__main__":
    app.run(debug=True)
    
    
